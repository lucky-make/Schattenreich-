import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Volume2, Shield, Swords, Heart, Trophy, Check, X } from 'lucide-react';
import { getZoneById } from '@/data/zones';
import confetti from 'canvas-confetti';

interface BossBattleProps {
  zoneId: number;
  onDefeat: (score: number) => void;
  onFail: () => void;
  onBack: () => void;
}

export function BossBattle({ zoneId, onDefeat, onFail, onBack }: BossBattleProps) {
  const zone = getZoneById(zoneId);
  const [currentQ, setCurrentQ] = useState(0);
  const [hp, setHp] = useState(3);
  const [bossHp, setBossHp] = useState(10);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [phase, setPhase] = useState<'battle' | 'victory' | 'defeat'>('battle');

  if (!zone) return null;

  const questions = zone.boss;
  const q = questions[currentQ];

  const handleAnswer = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);

    const isCorrect = idx === q.correct;
    
    setTimeout(() => {
      if (isCorrect) {
        setBossHp(b => b - 1);
        setScore(s => s + 20);
        
        if (bossHp <= 1) {
          setPhase('victory');
          confetti({ particleCount: 200, spread: 100, origin: { y: 0.6 }, colors: ['#FFD700', '#FF4500', '#F5E6D3'] });
          setTimeout(() => onDefeat(score + 20), 3000);
          return;
        }
      } else {
        setHp(h => h - 1);
        
        if (hp <= 1) {
          setPhase('defeat');
          setTimeout(() => onFail(), 3000);
          return;
        }
      }

      setCurrentQ(c => (c + 1) % questions.length);
      setSelected(null);
    }, 1000);
  };

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'de-DE';
    utterance.rate = 0.85;
    window.speechSynthesis.speak(utterance);
  };

  if (phase === 'victory') {
    return (
      <div className="max-w-2xl mx-auto text-center py-20">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', damping: 10 }}
        >
          <Trophy className="w-24 h-24 text-gold mx-auto mb-6" />
        </motion.div>
        <h2 className="text-4xl font-bold text-gold mb-4" style={{ fontFamily: 'Cinzel, serif' }}>
          Sieg!
        </h2>
        <p className="text-xl text-cream mb-2">Zone {zoneId} gemeistert</p>
        <p className="text-gold text-lg">+{score} XP • +150 Gold • Artefakt erhalten!</p>
      </div>
    );
  }

  if (phase === 'defeat') {
    return (
      <div className="max-w-2xl mx-auto text-center py-20">
        <Shield className="w-20 h-20 text-red-400 mx-auto mb-6" />
        <h2 className="text-3xl font-bold text-red-400 mb-4" style={{ fontFamily: 'Cinzel, serif' }}>
          Niederlage
        </h2>
        <p className="text-cream/80 mb-4">Der Boss war zu stark. Versuche es später erneut.</p>
        <p className="text-sm text-slate">-40 Gold Strafe</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button onClick={onBack} className="p-2 rounded-lg hover:bg-white/5 transition-colors">
          <ArrowLeft className="w-5 h-5 text-slate" />
        </button>
        <div className="flex-1">
          <h2 className="text-xl font-bold text-red-400" style={{ fontFamily: 'Cinzel, serif' }}>
            Boss Kampf
          </h2>
          <p className="text-sm text-slate">Zone {zoneId}: {zone.name}</p>
        </div>
        <Swords className="w-6 h-6 text-red-400" />
      </div>

      {/* Battle Arena */}
      <div className="bg-gradient-to-br from-[#1a0a3e] to-[#0d0221] border border-red-500/30 rounded-2xl p-6 md:p-8">
        {/* HP Bars */}
        <div className="flex items-center justify-between mb-8">
          {/* Player HP */}
          <div className="flex items-center gap-2">
            <div className="flex gap-1">
              {[...Array(3)].map((_, i) => (
                <Heart key={i} className={`w-5 h-5 ${i < hp ? 'text-red-500 fill-red-500' : 'text-slate/30'}`} />
              ))}
            </div>
          </div>

          <span className="text-sm font-bold text-gold" style={{ fontFamily: 'Cinzel, serif' }}>
            VS
          </span>

          {/* Boss HP */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-red-400">Boss</span>
            <div className="w-32 h-3 bg-[#0a0020] rounded-full overflow-hidden border border-red-500/30">
              <motion.div
                className="h-full bg-gradient-to-r from-red-600 to-orange-500"
                initial={{ width: '100%' }}
                animate={{ width: `${(bossHp / 10) * 100}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>
        </div>

        {/* Question */}
        <div className="text-center mb-6">
          <p className="text-sm text-slate mb-3">Frage {currentQ + 1}</p>
          <p className="text-xl md:text-2xl font-bold text-cream mb-3">{q.q}</p>
          {q.de && (
            <button
              onClick={() => speak(q.de!)}
              className="p-2 rounded-lg hover:bg-white/5 transition-colors inline-flex items-center gap-2"
            >
              <Volume2 className="w-4 h-4 text-gold" />
              <span className="text-xs text-gold german-text">{q.de}</span>
            </button>
          )}
        </div>

        {/* Options */}
        <div className="space-y-3">
          {q.opts.map((opt: string, i: number) => (
            <motion.button
              key={i}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleAnswer(i)}
              disabled={selected !== null}
              className={`w-full p-4 rounded-xl border text-left transition-all
                ${selected === null
                  ? 'bg-[#0a0020]/50 border-gold/20 hover:border-gold/50'
                  : i === q.correct
                    ? 'bg-emerald-900/30 border-emerald-500/50'
                    : selected === i
                      ? 'bg-red-900/30 border-red-500/50'
                      : 'bg-[#0a0020]/30 border-slate/20 opacity-50'
                }
              `}
            >
              <span className="text-cream">{opt}</span>
              {selected !== null && i === q.correct && (
                <Check className="inline w-5 h-5 text-emerald-400 ml-2" />
              )}
              {selected === i && i !== q.correct && (
                <X className="inline w-5 h-5 text-red-400 ml-2" />
              )}
            </motion.button>
          ))}
        </div>

        {/* Score */}
        <div className="mt-6 text-center">
          <span className="text-sm text-gold">Score: {score}</span>
        </div>
      </div>
    </div>
  );
}
