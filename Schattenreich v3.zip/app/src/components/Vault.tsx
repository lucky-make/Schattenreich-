import { motion } from 'framer-motion';
import { ArrowLeft, Gem, Lock, Sparkles } from 'lucide-react';
import { getZoneById } from '@/data/zones';

interface VaultProps {
  artifacts: string[];
  onBack: () => void;
}

export function Vault({ artifacts, onBack }: VaultProps) {
  const completedZones = artifacts
    .filter(a => a.startsWith('zone-'))
    .map(a => parseInt(a.replace('zone-', '')))
    .sort((a, b) => a - b);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <button onClick={onBack} className="p-2 rounded-lg hover:bg-white/5 transition-colors">
          <ArrowLeft className="w-5 h-5 text-slate" />
        </button>
        <h1 className="text-3xl font-bold text-gold" style={{ fontFamily: 'Cinzel, serif' }}>
          Die Schatzkammer
        </h1>
        <Gem className="w-6 h-6 text-purple-400" />
      </div>

      <div className="mb-6">
        <p className="text-cream/80">
          Du hast <span className="text-gold font-bold">{completedZones.length}</span> Artefakte gesammelt.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3">
        {Array.from({ length: 120 }, (_, i) => i + 1).map((zoneId) => {
          const hasArtifact = completedZones.includes(zoneId);
          const zone = getZoneById(zoneId);
          
          return (
            <motion.div
              key={zoneId}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: zoneId * 0.01 }}
              className={`relative aspect-square rounded-xl border p-3 flex flex-col items-center justify-center
                ${hasArtifact
                  ? 'bg-gradient-to-br from-amber-900/30 to-purple-900/30 border-gold/40'
                  : 'bg-[#0a0020]/40 border-slate/20 opacity-40'
                }
              `}
            >
              {hasArtifact ? (
                <>
                  <span className="text-2xl mb-1">{zone?.emoji || '📍'}</span>
                  <Sparkles className="w-3 h-3 text-gold absolute top-2 right-2" />
                  <span className="text-xs font-bold text-gold">{zoneId}</span>
                </>
              ) : (
                <>
                  <Lock className="w-5 h-5 text-slate/50 mb-1" />
                  <span className="text-xs text-slate/50">{zoneId}</span>
                </>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
