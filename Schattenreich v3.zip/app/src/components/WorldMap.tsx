import { useRef, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Lock, CheckCircle2, ChevronRight, Star } from 'lucide-react';
import { getZoneById } from '@/data/zones';

interface WorldMapProps {
  zones: number[];
  currentZone: number;
  completedZones: number[];
  unlockedZones: number[];
  onSelectZone: (zoneId: number) => void;
}

export function WorldMap({ zones, currentZone, completedZones, unlockedZones, onSelectZone }: WorldMapProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [hoveredZone, setHoveredZone] = useState<number | null>(null);

  // Group zones into chapters (16 zones per chapter)
  const chapters = useMemo(() => {
    const ch = [];
    for (let i = 0; i < 120; i += 16) {
      ch.push(zones.slice(i, i + 16));
    }
    return ch;
  }, [zones]);

  const chapterNames = [
    "Das stille Erwachen (A1.1)",
    "Der Morgen des Wissens (A1.2)",
    "Die Reise beginnt (A2.1)",
    "Der Pfad der Tiefe (A2.2)",
    "Die Brücke zum B1 (B1.1)",
    "Das Reich der Komplexität (B1.2)",
    "Der Aufstieg (B2.1)",
    "Die Krönung (B2.2)",
  ];

  return (
    <div className="max-w-6xl mx-auto">
      {/* Title */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <h1 className="text-3xl md:text-4xl font-bold text-gold text-shadow-gold mb-2" style={{ fontFamily: 'Cinzel, serif' }}>
          Die Weltkarte
        </h1>
        <p className="text-slate text-sm md:text-base">
          120 Zonen warten auf dich. Jeder Schritt bringt dich der Meisterschaft näher.
        </p>
      </motion.div>

      {/* Zone count */}
      <div className="flex justify-center gap-6 mb-8 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-emerald-500" />
          <span className="text-cream/70">{completedZones.length} gemeistert</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-amber-500" />
          <span className="text-cream/70">{unlockedZones.filter(z => !completedZones.includes(z)).length} offen</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-slate/40" />
          <span className="text-cream/70">{120 - unlockedZones.length} verschlossen</span>
        </div>
      </div>

      {/* Map */}
      <div ref={scrollRef} className="space-y-8 pb-20">
        {chapters.map((chapterZones, chapterIdx) => (
          <motion.div
            key={chapterIdx}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: chapterIdx * 0.1 }}
            className="relative"
          >
            {/* Chapter header */}
            <div className="flex items-center gap-3 mb-4 px-2">
              <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gold/30 to-transparent" />
              <h2 className="text-sm md:text-base font-semibold text-gold/80 whitespace-nowrap" style={{ fontFamily: 'Cinzel, serif' }}>
                Kapitel {chapterIdx + 1}: {chapterNames[chapterIdx]}
              </h2>
              <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gold/30 to-transparent" />
            </div>

            {/* Zone grid */}
            <div className="grid grid-cols-4 sm:grid-cols-8 gap-2 md:gap-3">
              {chapterZones.map((zoneId) => {
                const zone = getZoneById(zoneId);
                const isCompleted = completedZones.includes(zoneId);
                const isUnlocked = unlockedZones.includes(zoneId);
                const isCurrent = currentZone === zoneId;
                const isHovered = hoveredZone === zoneId;

                return (
                  <motion.button
                    key={zoneId}
                    whileHover={isUnlocked ? { scale: 1.1 } : {}}
                    whileTap={isUnlocked ? { scale: 0.95 } : {}}
                    onClick={() => isUnlocked && onSelectZone(zoneId)}
                    onMouseEnter={() => setHoveredZone(zoneId)}
                    onMouseLeave={() => setHoveredZone(null)}
                    className={`relative aspect-square rounded-xl border transition-all duration-300
                      ${isCompleted
                        ? 'bg-emerald-900/30 border-emerald-500/50 shadow-emerald-500/20'
                        : isUnlocked
                          ? 'bg-[#1a0a3e]/80 border-gold/40 hover:border-gold/80 hover:shadow-lg hover:shadow-gold/20'
                          : 'bg-[#0a0020]/60 border-slate/20 opacity-50 cursor-not-allowed'
                      }
                      ${isCurrent ? 'ring-2 ring-gold ring-offset-2 ring-offset-[#0a0020]' : ''}
                    `}
                  >
                    {/* Zone content */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-1">
                      {isCompleted ? (
                        <CheckCircle2 className="w-5 h-5 md:w-6 md:h-6 text-emerald-400" />
                      ) : !isUnlocked ? (
                        <Lock className="w-4 h-4 md:w-5 md:h-5 text-slate/50" />
                      ) : (
                        <span className="text-lg md:text-xl">{zone?.emoji || '📍'}</span>
                      )}
                      <span className={`text-xs mt-0.5 font-bold ${isCompleted ? 'text-emerald-400' : isUnlocked ? 'text-gold' : 'text-slate/50'}`}>
                        {zoneId}
                      </span>
                    </div>

                    {/* Glow effect for current */}
                    {isCurrent && (
                      <div className="absolute inset-0 rounded-xl animate-glow pointer-events-none" />
                    )}

                    {/* Tooltip */}
                    {isHovered && isUnlocked && zone && (
                      <motion.div
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 z-50 
                                   bg-[#1a0a3e] border border-gold/30 rounded-lg px-3 py-2 
                                   shadow-xl min-w-[140px] pointer-events-none"
                      >
                        <p className="text-xs font-bold text-gold truncate">{zone.name}</p>
                        <p className="text-xs text-slate">{zone.subtitle}</p>
                        <p className="text-xs text-cream/70">{zone.level}</p>
                      </motion.div>
                    )}
                  </motion.button>
                );
              })}
            </div>

            {/* Path connector */}
            {chapterIdx < chapters.length - 1 && (
              <div className="flex justify-center py-4">
                <div className="flex flex-col items-center gap-1">
                  <div className="w-0.5 h-4 bg-gradient-to-b from-gold/40 to-gold/20" />
                  <ChevronRight className="w-4 h-4 text-gold/40 rotate-90" />
                </div>
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {/* Legend */}
      <div className="fixed bottom-6 left-6 z-40 bg-[#0a0020]/90 backdrop-blur-sm 
                      border border-gold/20 rounded-lg px-4 py-2 text-xs space-y-1">
        <div className="flex items-center gap-2">
          <Star className="w-3 h-3 text-gold" />
          <span className="text-cream/70">Aktuelle Zone</span>
        </div>
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
          <span className="text-cream/70">Gemeistert</span>
        </div>
        <div className="flex items-center gap-2">
          <Lock className="w-3 h-3 text-slate" />
          <span className="text-cream/70">Verschlossen</span>
        </div>
      </div>
    </div>
  );
}
