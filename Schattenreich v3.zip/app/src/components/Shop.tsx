import { motion } from 'framer-motion';
import { ArrowLeft, ShoppingBag, Coins, Check } from 'lucide-react';

interface ShopProps {
  gold: number;
  artifacts: string[];
  onBuy: (itemId: string, cost: number) => void;
  onBack: () => void;
}

const shopItems = [
  { id: 'theme-forest', name: 'Wald-Thema', description: 'Verändere das Aussehen der Karte', cost: 200, icon: '🌲' },
  { id: 'theme-ocean', name: 'Ozean-Thema', description: 'Tiefblaue Ästhetik', cost: 250, icon: '🌊' },
  { id: 'theme-magma', name: 'Magma-Thema', description: 'Feuriges Design', cost: 300, icon: '🔥' },
  { id: 'fox-hat', name: 'Bertrams Hut', description: 'Ein süßer Hut für Bertram', cost: 150, icon: '🎩' },
  { id: 'fox-glasses', name: 'Bertrams Brille', description: 'Schick und gebildet', cost: 180, icon: '👓' },
  { id: 'pet-companion', name: 'Eulen-Begleiter', description: 'Eine weise Eule', cost: 500, icon: '🦉' },
];

export function Shop({ gold, artifacts, onBuy, onBack }: ShopProps) {
  const hasItem = (id: string) => artifacts.includes(id);

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <button onClick={onBack} className="p-2 rounded-lg hover:bg-white/5 transition-colors">
          <ArrowLeft className="w-5 h-5 text-slate" />
        </button>
        <h1 className="text-3xl font-bold text-gold" style={{ fontFamily: 'Cinzel, serif' }}>
          Der Gildenladen
        </h1>
        <ShoppingBag className="w-6 h-6 text-emerald-400" />
      </div>

      <div className="mb-6 flex items-center gap-2">
        <Coins className="w-5 h-5 text-gold" />
        <span className="text-lg font-bold text-gold">{gold} Gold</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {shopItems.map((item, idx) => {
          const owned = hasItem(item.id);
          const canAfford = gold >= item.cost;

          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className={`p-4 rounded-xl border transition-all
                ${owned
                  ? 'bg-emerald-900/20 border-emerald-500/40'
                  : 'bg-[#1a0a3e]/60 border-gold/20'
                }
              `}
            >
              <div className="flex items-start gap-4">
                <span className="text-3xl">{item.icon}</span>
                <div className="flex-1">
                  <h3 className="font-semibold text-cream">{item.name}</h3>
                  <p className="text-xs text-slate">{item.description}</p>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1 text-gold">
                    <Coins className="w-4 h-4" />
                    <span className="text-sm font-bold">{item.cost}</span>
                  </div>
                  {owned ? (
                    <div className="flex items-center gap-1 text-emerald-400 text-xs mt-1">
                      <Check className="w-3 h-3" />
                      <span>Im Besitz</span>
                    </div>
                  ) : (
                    <button
                      onClick={() => canAfford && onBuy(item.id, item.cost)}
                      disabled={!canAfford}
                      className={`mt-1 px-3 py-1 rounded-lg text-xs font-semibold transition-all
                        ${canAfford
                          ? 'bg-gold/20 text-gold border border-gold/40 hover:bg-gold/30'
                          : 'bg-[#0a0020]/40 text-slate/50 border border-slate/20 cursor-not-allowed'
                        }
                      `}
                    >
                      {canAfford ? 'Kaufen' : 'Zu teuer'}
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
