import { useState, useEffect, useMemo, useRef } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Volume2, Check, X, Mic, Square, Trophy } from 'lucide-react';
import { getZoneById } from '@/data/zones';
import type { TrialType } from '@/types/game';
import confetti from 'canvas-confetti';

interface TrialScreenProps {
  trialType: TrialType;
  zoneId: number;
  onComplete: (score: number, gold: number) => void;
  onBack: () => void;
}

export function TrialScreen({ trialType, zoneId, onComplete, onBack }: TrialScreenProps) {
  const zone = getZoneById(zoneId);
  if (!zone) return null;

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={onBack}
          className="p-2 rounded-lg hover:bg-white/5 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-slate" />
        </button>
        <div>
          <h2 className="text-xl font-bold text-gold" style={{ fontFamily: 'Cinzel, serif' }}>
            {getTrialName(trialType)}
          </h2>
          <p className="text-sm text-slate">Zone {zoneId}: {zone.name}</p>
        </div>
      </div>

      {/* Trial Content */}
      <div className="bg-gradient-to-br from-[#1a0a3e] to-[#0d0221] border border-gold/20 rounded-2xl p-6">
        {trialType === 'lexicon' && (
          <LexiconTrial vocab={zone.vocab} onComplete={onComplete} />
        )}
        {trialType === 'sentence' && (
          <SentenceTrial sentences={zone.sentences} onComplete={onComplete} />
        )}
        {trialType === 'listening' && (
          <ListeningTrial dictation={zone.dictation} onComplete={onComplete} />
        )}
        {trialType === 'speaking' && (
          <SpeakingTrial prompts={zone.speaking} onComplete={onComplete} />
        )}
        {trialType === 'grammar' && (
          <GrammarTrial grammar={zone.grammar} vocab={zone.vocab} onComplete={onComplete} />
        )}
        {trialType === 'writing' && (
          <WritingTrial prompts={zone.speaking.slice(0, 2)} onComplete={onComplete} />
        )}
      </div>
    </div>
  );
}

function getTrialName(type: TrialType): string {
  const names: Record<TrialType, string> = {
    lexicon: 'Lexicon-Keller',
    sentence: 'Satz-Schmiede',
    listening: 'Hör-Gewölbe',
    speaking: 'Sprech-Halle',
    grammar: 'Grammatik-Keller',
    writing: 'Schreib-Gewölbe',
  };
  return names[type];
}

/* ─── LEXICON TRIAL ─── */
function LexiconTrial({ vocab, onComplete }: { vocab: any[], onComplete: (s: number, g: number) => void }) {
  const [phase, setPhase] = useState<'study' | 'quiz'>('study');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selected, setSelected] = useState<number | null>(null);
  const [quizWords] = useState(() => shuffleArray(vocab.slice(0, 10)));

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'de-DE';
    utterance.rate = 0.85;
    utterance.pitch = 1.1;
    window.speechSynthesis.speak(utterance);
  };

  const startQuiz = () => {
    setPhase('quiz');
    setCurrentIdx(0);
  };

  const handleAnswer = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    
    const isCorrect = idx === 0; // First option is always correct (shuffled)
    if (isCorrect) {
      setScore(s => s + 10);
    }
    
    setTimeout(() => {
      if (currentIdx < quizWords.length - 1) {
        setCurrentIdx(c => c + 1);
        setSelected(null);
      } else {
        setShowResult(true);
        const totalScore = score + (isCorrect ? 10 : 0);
        const gold = Math.floor(totalScore / 5);
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 }, colors: ['#FFD700', '#F5E6D3', '#7B8CA8'] });
        setTimeout(() => onComplete(totalScore, gold), 2000);
      }
    }, 1000);
  };

  const word = quizWords[currentIdx];
  const options = generateOptions(word, vocab);

  if (showResult) {
    return (
      <div className="text-center py-12">
        <Trophy className="w-16 h-16 text-gold mx-auto mb-4" />
        <h3 className="text-2xl font-bold text-gold mb-2">Prüfung bestanden!</h3>
        <p className="text-cream/80">Score: {score}/100</p>
        <p className="text-gold mt-2">+{Math.floor(score / 5)} Gold</p>
      </div>
    );
  }

  if (phase === 'study') {
    return (
      <div>
        <h3 className="text-lg font-semibold text-cream mb-4">Lernphase</h3>
        <p className="text-sm text-slate mb-6">Studiere die Wörter und tippe auf das Lautsprechersymbol, um die Aussprache zu hören.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6">
          {quizWords.map((w: any, i: number) => (
            <div key={i} className="bg-[#0a0020]/50 border border-gold/20 rounded-lg p-3 flex items-center justify-between">
              <div>
                <p className="text-cream font-semibold german-text">{w.article ? `${w.article} ` : ''}{w.de}</p>
                <p className="text-xs text-slate">{w.en}</p>
              </div>
              <button
                onClick={() => speak(w.de)}
                className="p-2 rounded-lg hover:bg-white/5 transition-colors"
              >
                <Volume2 className="w-4 h-4 text-gold" />
              </button>
            </div>
          ))}
        </div>
        
        <button
          onClick={startQuiz}
          className="w-full py-3 bg-gold/20 border border-gold/50 rounded-lg text-gold 
                     font-semibold hover:bg-gold/30 transition-colors"
        >
          Quiz starten
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <span className="text-sm text-slate">Frage {currentIdx + 1}/{quizWords.length}</span>
        <span className="text-sm text-gold">Score: {score}</span>
      </div>

      <div className="text-center mb-8">
        <p className="text-sm text-slate mb-2">Was bedeutet:</p>
        <p className="text-3xl font-bold text-gold german-text mb-4">
          {word.article ? `${word.article} ` : ''}{word.de}
        </p>
        <button
          onClick={() => speak(word.de)}
          className="p-2 rounded-lg hover:bg-white/5 transition-colors"
        >
          <Volume2 className="w-5 h-5 text-gold" />
        </button>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {options.map((opt: any, i: number) => (
          <motion.button
            key={i}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => handleAnswer(i)}
            disabled={selected !== null}
            className={`p-4 rounded-xl border text-left transition-all
              ${selected === null
                ? 'bg-[#0a0020]/50 border-gold/20 hover:border-gold/50'
                : i === 0
                  ? 'bg-emerald-900/30 border-emerald-500/50'
                  : selected === i
                    ? 'bg-red-900/30 border-red-500/50'
                    : 'bg-[#0a0020]/30 border-slate/20 opacity-50'
              }
            `}
          >
            <span className="text-cream">{opt.en}</span>
            {selected !== null && i === 0 && <Check className="inline w-4 h-4 text-emerald-400 ml-2" />}
            {selected === i && i !== 0 && <X className="inline w-4 h-4 text-red-400 ml-2" />}
          </motion.button>
        ))}
      </div>
    </div>
  );
}

/* ─── SENTENCE TRIAL ─── */
function SentenceTrial({ sentences, onComplete }: { sentences: any[], onComplete: (s: number, g: number) => void }) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [parts, setParts] = useState<string[]>([]);
  const [score, setScore] = useState(0);
  const [checked, setChecked] = useState(false);
  const [quizSentences] = useState(() => shuffleArray(sentences.slice(0, 5)));

  const sentence = quizSentences[currentIdx];
  const shuffledParts = useState(() => shuffleArray([...sentence.parts]))[0];

  useEffect(() => {
    setParts([]);
    setChecked(false);
  }, [currentIdx]);

  const addPart = (part: string) => {
    if (checked) return;
    setParts(p => [...p, part]);
  };

  const removePart = (idx: number) => {
    if (checked) return;
    setParts(p => p.filter((_, i) => i !== idx));
  };

  const checkAnswer = () => {
    setChecked(true);
    const isCorrect = JSON.stringify(parts) === JSON.stringify(sentence.parts);
    if (isCorrect) {
      setScore(s => s + 20);
    }
  };

  const nextSentence = () => {
    if (currentIdx < quizSentences.length - 1) {
      setCurrentIdx(c => c + 1);
    } else {
      const gold = Math.floor(score / 10);
      confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 }, colors: ['#FFD700', '#F5E6D3', '#7B8CA8'] });
      onComplete(score, gold);
    }
  };

  const availableParts = shuffledParts.filter(p => !parts.includes(p) || parts.filter(x => x === p).length < shuffledParts.filter(x => x === p).length);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <span className="text-sm text-slate">Satz {currentIdx + 1}/{quizSentences.length}</span>
        <span className="text-sm text-gold">Score: {score}</span>
      </div>

      <p className="text-sm text-slate mb-2">Übersetzung:</p>
      <p className="text-cream italic mb-6">{sentence.translation}</p>

      {/* Answer area */}
      <div className="min-h-[60px] bg-[#0a0020]/50 border-2 border-gold/30 rounded-xl p-4 mb-6 
                      flex flex-wrap gap-2 items-center">
        {parts.length === 0 ? (
          <span className="text-slate/50 text-sm">Baue den Satz zusammen...</span>
        ) : (
          parts.map((part, i) => (
            <motion.button
              key={i}
              whileTap={{ scale: 0.95 }}
              onClick={() => !checked && removePart(i)}
              disabled={checked}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all
                ${checked
                  ? JSON.stringify(parts) === JSON.stringify(sentence.parts)
                    ? 'bg-emerald-900/50 text-emerald-300'
                    : 'bg-red-900/50 text-red-300'
                  : 'bg-gold/20 text-gold hover:bg-gold/30'
                }
              `}
            >
              {part}
            </motion.button>
          ))
        )}
      </div>

      {/* Word bank */}
      <div className="flex flex-wrap gap-2 mb-6">
        {availableParts.map((part, i) => (
          <motion.button
            key={i}
            whileTap={{ scale: 0.95 }}
            onClick={() => addPart(part)}
            disabled={checked}
            className="px-3 py-1.5 rounded-lg text-sm bg-[#1a0a3e] border border-gold/20 
                       text-cream hover:border-gold/50 hover:bg-[#2a1a4e] transition-all
                       disabled:opacity-30"
          >
            {part}
          </motion.button>
        ))}
      </div>

      {/* Actions */}
      {!checked ? (
        <button
          onClick={checkAnswer}
          disabled={parts.length === 0}
          className="w-full py-3 bg-gold/20 border border-gold/50 rounded-lg text-gold 
                     font-semibold hover:bg-gold/30 transition-colors disabled:opacity-30"
        >
          Überprüfen
        </button>
      ) : (
        <div className="text-center">
          {JSON.stringify(parts) === JSON.stringify(sentence.parts) ? (
            <div className="flex items-center justify-center gap-2 text-emerald-400 mb-4">
              <Check className="w-5 h-5" />
              <span className="font-semibold">Richtig!</span>
            </div>
          ) : (
            <div className="mb-4">
              <div className="flex items-center justify-center gap-2 text-red-400 mb-2">
                <X className="w-5 h-5" />
                <span className="font-semibold">Falsch</span>
              </div>
              <p className="text-sm text-slate">
                Richtige Antwort: <span className="text-emerald-300">{sentence.parts.join(' ')}</span>
              </p>
            </div>
          )}
          <button
            onClick={nextSentence}
            className="px-6 py-2 bg-gold/20 border border-gold/50 rounded-lg text-gold 
                       font-semibold hover:bg-gold/30 transition-colors"
          >
            {currentIdx < quizSentences.length - 1 ? 'Nächster Satz' : 'Abschließen'}
          </button>
        </div>
      )}
    </div>
  );
}

/* ─── LISTENING TRIAL ─── */
function ListeningTrial({ dictation, onComplete }: { dictation: string[], onComplete: (s: number, g: number) => void }) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [input, setInput] = useState('');
  const [score, setScore] = useState(0);
  const [checked, setChecked] = useState(false);
  const [quizDictation] = useState(() => shuffleArray(dictation.slice(0, 5)));

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'de-DE';
    utterance.rate = 0.8;
    window.speechSynthesis.speak(utterance);
  };

  const checkAnswer = () => {
    setChecked(true);
    const target = quizDictation[currentIdx];
    const similarity = calculateSimilarity(input.trim().toLowerCase(), target.toLowerCase());
    if (similarity > 0.8) {
      setScore(s => s + 20);
    }
  };

  const next = () => {
    if (currentIdx < quizDictation.length - 1) {
      setCurrentIdx(c => c + 1);
      setInput('');
      setChecked(false);
    } else {
      const gold = Math.floor(score / 10);
      confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 }, colors: ['#FFD700', '#F5E6D3', '#7B8CA8'] });
      onComplete(score, gold);
    }
  };

  const sentence = quizDictation[currentIdx];

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <span className="text-sm text-slate">Diktat {currentIdx + 1}/{quizDictation.length}</span>
        <span className="text-sm text-gold">Score: {score}</span>
      </div>

      <button
        onClick={() => speak(sentence)}
        className="w-full py-4 bg-[#0a0020]/50 border border-gold/30 rounded-xl 
                   flex items-center justify-center gap-3 hover:border-gold/60 
                   transition-colors mb-6"
      >
        <Volume2 className="w-6 h-6 text-gold" />
        <span className="text-gold font-semibold">Satz abspielen</span>
      </button>

      <textarea
        value={input}
        onChange={(e) => !checked && setInput(e.target.value)}
        placeholder="Tippe, was du gehört hast..."
        className="w-full h-24 bg-[#0a0020]/50 border border-gold/20 rounded-xl p-4 
                   text-cream placeholder:text-slate/50 resize-none focus:border-gold/50 
                   focus:outline-none transition-colors mb-4"
        disabled={checked}
      />

      {!checked ? (
        <button
          onClick={checkAnswer}
          disabled={!input.trim()}
          className="w-full py-3 bg-gold/20 border border-gold/50 rounded-lg text-gold 
                     font-semibold hover:bg-gold/30 transition-colors disabled:opacity-30"
        >
          Überprüfen
        </button>
      ) : (
        <div className="text-center">
          <div className="mb-4">
            <p className="text-sm text-slate mb-1">Richtige Antwort:</p>
            <p className="text-cream german-text">{sentence}</p>
          </div>
          <p className="text-sm text-slate mb-4">
            Deine Antwort: <span className={calculateSimilarity(input.toLowerCase(), sentence.toLowerCase()) > 0.8 ? 'text-emerald-300' : 'text-red-300'}>{input}</span>
          </p>
          <button
            onClick={next}
            className="px-6 py-2 bg-gold/20 border border-gold/50 rounded-lg text-gold 
                       font-semibold hover:bg-gold/30 transition-colors"
          >
            {currentIdx < quizDictation.length - 1 ? 'Nächstes Diktat' : 'Abschließen'}
          </button>
        </div>
      )}
    </div>
  );
}

/* ─── SPEAKING TRIAL ─── */
function SpeakingTrial({ prompts, onComplete }: { prompts: string[], onComplete: (s: number, g: number) => void }) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [feedback, setFeedback] = useState<{ similarity: number; matched: string[]; missed: string[] } | null>(null);
  const [score, setScore] = useState(0);
  const [unsupported, setUnsupported] = useState(false);
  const recognitionRef = useRef<any>(null);

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'de-DE';
    utterance.rate = 0.85;
    window.speechSynthesis.speak(utterance);
  };

  const startRecording = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setUnsupported(true);
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = 'de-DE';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognitionRef.current = recognition;

    recognition.onresult = (event: any) => {
      const said = event.results[0][0].transcript;
      setTranscript(said);
      evaluateSpeech(said, prompts[currentIdx]);
      setIsRecording(false);
    };

    recognition.onerror = () => {
      setIsRecording(false);
      setTranscript('');
    };

    recognition.onend = () => {
      setIsRecording(false);
    };

    recognition.start();
    setIsRecording(true);
    setTranscript('');
    setFeedback(null);
  };

  const stopRecording = () => {
    recognitionRef.current?.stop();
    setIsRecording(false);
  };

  const evaluateSpeech = (said: string, prompt: string) => {
    const normalise = (s: string) => s.toLowerCase().replace(/[.,!?;:]/g, '').trim();
    const saidWords = normalise(said).split(/\s+/);
    const promptWords = normalise(prompt).split(/\s+/);

    const matched = promptWords.filter(w => saidWords.includes(w));
    const missed = promptWords.filter(w => !saidWords.includes(w));
    const similarity = matched.length / promptWords.length;

    setFeedback({ similarity, matched, missed });

    const roundScore = Math.round(similarity * 30);
    setScore(s => s + roundScore);
  };

  const next = () => {
    if (currentIdx < prompts.length - 1) {
      setCurrentIdx(c => c + 1);
      setTranscript('');
      setFeedback(null);
    } else {
      const gold = Math.floor(score / 10);
      confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 }, colors: ['#FFD700', '#F5E6D3'] });
      onComplete(score, gold);
    }
  };

  const prompt = prompts[currentIdx];

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <span className="text-sm text-slate">Prompt {currentIdx + 1}/{prompts.length}</span>
        <span className="text-sm text-gold">Score: {score}</span>
      </div>

      {/* Prompt card */}
      <div className="bg-[#0a0020]/50 border border-gold/20 rounded-xl p-5 mb-6">
        <p className="text-xs text-slate uppercase tracking-wider mb-2">Sprich diesen Satz:</p>
        <div className="flex items-center gap-3">
          <p className="text-cream text-lg flex-1 german-text">{prompt}</p>
          <button onClick={() => speak(prompt)} className="p-2 rounded-lg hover:bg-white/5 transition-colors shrink-0">
            <Volume2 className="w-5 h-5 text-gold" />
          </button>
        </div>
      </div>

      {unsupported && (
        <div className="bg-red-900/20 border border-red-500/30 rounded-xl p-4 mb-4 text-center">
          <p className="text-red-300 text-sm">Spracherkennung wird in diesem Browser nicht unterstützt. Bitte Chrome verwenden.</p>
        </div>
      )}

      {/* Record button */}
      {!feedback && (
        <div className="flex justify-center mb-6">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={isRecording ? stopRecording : startRecording}
            className={`w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300
              ${isRecording
                ? 'bg-red-500/30 border-2 border-red-400 animate-pulse'
                : 'bg-gold/20 border-2 border-gold/50 hover:bg-gold/30'
              }`}
          >
            {isRecording ? <Square className="w-7 h-7 text-red-400" /> : <Mic className="w-7 h-7 text-gold" />}
          </motion.button>
        </div>
      )}

      {isRecording && (
        <p className="text-center text-sm text-slate mb-4 animate-pulse">Hört zu... Sprich jetzt!</p>
      )}

      {/* Transcript */}
      {transcript && !feedback && (
        <div className="bg-[#0a0020]/50 border border-gold/20 rounded-xl p-4 mb-4 text-center">
          <p className="text-xs text-slate mb-1">Du hast gesagt:</p>
          <p className="text-cream german-text">„{transcript}"</p>
        </div>
      )}

      {/* Feedback */}
      {feedback && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-5">
          {/* Score bar */}
          <div className="bg-[#0a0020]/50 border border-gold/20 rounded-xl p-4 mb-3">
            <div className="flex justify-between text-xs text-slate mb-2">
              <span>Aussprache-Score</span>
              <span className="text-gold">{Math.round(feedback.similarity * 100)}%</span>
            </div>
            <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${feedback.similarity * 100}%` }}
                transition={{ duration: 0.8 }}
                className={`h-full rounded-full ${feedback.similarity > 0.7 ? 'bg-emerald-400' : feedback.similarity > 0.4 ? 'bg-yellow-400' : 'bg-red-400'}`}
              />
            </div>
          </div>

          {/* What you said */}
          <div className="bg-[#0a0020]/50 border border-gold/20 rounded-xl p-4 mb-3">
            <p className="text-xs text-slate mb-1">Du hast gesagt:</p>
            <p className="text-cream german-text">„{transcript}"</p>
          </div>

          {/* Word breakdown */}
          {feedback.missed.length > 0 && (
            <div className="bg-red-900/20 border border-red-500/20 rounded-xl p-4 mb-3">
              <p className="text-xs text-red-300 mb-2">Fehlende Wörter:</p>
              <div className="flex flex-wrap gap-2">
                {feedback.missed.map((w, i) => (
                  <span key={i} className="px-2 py-1 bg-red-900/30 rounded text-red-300 text-sm german-text">{w}</span>
                ))}
              </div>
            </div>
          )}

          {feedback.matched.length > 0 && (
            <div className="bg-emerald-900/20 border border-emerald-500/20 rounded-xl p-4 mb-4">
              <p className="text-xs text-emerald-300 mb-2">Richtige Wörter:</p>
              <div className="flex flex-wrap gap-2">
                {feedback.matched.map((w, i) => (
                  <span key={i} className="px-2 py-1 bg-emerald-900/30 rounded text-emerald-300 text-sm german-text">{w}</span>
                ))}
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <button
              onClick={() => { setFeedback(null); setTranscript(''); }}
              className="flex-1 py-3 bg-white/5 border border-white/10 rounded-lg text-slate hover:border-gold/30 transition-colors text-sm"
            >
              Nochmal versuchen
            </button>
            <button
              onClick={next}
              className="flex-1 py-3 bg-gold/20 border border-gold/50 rounded-lg text-gold font-semibold hover:bg-gold/30 transition-colors"
            >
              {currentIdx < prompts.length - 1 ? 'Weiter →' : 'Abschließen'}
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
}

/* ─── GRAMMAR TRIAL ─── */
function GrammarTrial({ grammar, vocab, onComplete }: { grammar: any[], vocab: any[], onComplete: (s: number, g: number) => void }) {
  const [phase, setPhase] = useState<'teach' | 'quiz'>('teach');
  const [teachIdx, setTeachIdx] = useState(0);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'de-DE';
    utterance.rate = 0.85;
    window.speechSynthesis.speak(utterance);
  };

  // Build fill-in-the-blank questions from grammar rules
  const questions = useMemo(() => {
    const qs: any[] = [];

    // Q1-Q3: Fill in the blank — blank is always a key word in the rule's example sentence
    grammar.slice(0, 3).forEach((rule: any, i: number) => {
      const words = rule.de.split(' ');
      // Pick the most grammatically significant word to blank (not trivial words)
      const skipWords = new Set(['ich', 'du', 'er', 'sie', 'es', 'wir', 'ihr', 'und', 'oder', 'ein', 'eine', 'ist', 'sind', 'der', 'die', 'das', 'in', 'zu', 'an', 'auf']);
      const candidateIdxs = words.map((w: string, idx: number) => idx).filter((idx: number) => !skipWords.has(words[idx].toLowerCase()) && words[idx].length > 2);
      const blankIdx = candidateIdxs.length > 0 ? candidateIdxs[Math.floor(candidateIdxs.length / 2)] : Math.floor(words.length / 2);
      const correctWord = words[blankIdx];
      const displayed = [...words];
      displayed[blankIdx] = '___';

      // Distractors: pull similar-length words from vocab + other rules
      const distractors: string[] = [];
      grammar.forEach((r: any, j: number) => {
        if (j !== i) {
          const rWords = r.de.split(' ');
          rWords.forEach((w: string) => {
            if (w.length > 2 && w.toLowerCase() !== correctWord.toLowerCase() && !skipWords.has(w.toLowerCase())) {
              distractors.push(w);
            }
          });
        }
      });
      vocab.slice(0, 10).forEach((v: any) => {
        if (v.de.split(' ').length === 1 && v.de.toLowerCase() !== correctWord.toLowerCase()) {
          distractors.push(v.de);
        }
      });

      const uniqueDistractors = [...new Set(distractors)].slice(0, 3);
      while (uniqueDistractors.length < 3) uniqueDistractors.push(['gemacht', 'kommen', 'hatten'][uniqueDistractors.length]);

      qs.push({
        type: 'fill',
        prompt: `Vervollständige den Satz:`,
        sentence: displayed.join(' '),
        translation: rule.en,
        options: shuffleArray([correctWord, ...uniqueDistractors.slice(0, 3)]),
        correct: correctWord,
        explanation: rule.rule,
        ruleTitle: rule.title,
      });
    });

    // Q4-Q5: Article questions with the why explained
    const articleWords = vocab.filter((w: any) => w.article).slice(0, 2);
    articleWords.forEach((word: any) => {
      const articles = ['der', 'die', 'das'];
      const correctArticle = word.article;
      const wrongArticles = articles.filter(a => a !== correctArticle);
      qs.push({
        type: 'article',
        prompt: `Welcher Artikel passt?`,
        sentence: `___ ${word.de.replace(/^(der|die|das)\s/i, '')}`,
        translation: word.en,
        options: shuffleArray([correctArticle, ...wrongArticles]),
        correct: correctArticle,
        explanation: `„${word.de}" ist ${correctArticle === 'der' ? 'maskulin' : correctArticle === 'die' ? 'feminin' : 'neutral'}. Merke dir: ${word.example}`,
        ruleTitle: 'Artikel',
      });
    });

    return qs;
  }, [grammar, vocab]);

  const teachCards = grammar.slice(0, 3);
  const currentQ = questions[currentIdx];

  const handleAnswer = (opt: string) => {
    if (selected !== null) return;
    setSelected(opt as any);
    const correct = opt === currentQ.correct;
    if (correct) setScore(s => s + 20);

    setTimeout(() => {
      if (currentIdx < questions.length - 1) {
        setCurrentIdx(c => c + 1);
        setSelected(null);
      } else {
        setShowResult(true);
        const finalScore = score + (correct ? 20 : 0);
        const gold = Math.floor(finalScore / 10);
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 }, colors: ['#FFD700', '#F5E6D3', '#7B8CA8'] });
        setTimeout(() => onComplete(finalScore, gold), 2000);
      }
    }, 1600);
  };

  if (showResult) {
    return (
      <div className="text-center py-12">
        <Trophy className="w-16 h-16 text-gold mx-auto mb-4" />
        <h3 className="text-2xl font-bold text-gold mb-2">Prüfung bestanden!</h3>
        <p className="text-cream/80">Score: {score}/{questions.length * 20}</p>
      </div>
    );
  }

  // ── TEACH PHASE ──
  if (phase === 'teach') {
    const card = teachCards[teachIdx];
    return (
      <div>
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm text-slate">Regel {teachIdx + 1} von {teachCards.length}</span>
          <span className="text-xs text-gold/60 uppercase tracking-wider">Lernphase</span>
        </div>

        <motion.div
          key={teachIdx}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-[#0a0020]/60 border border-gold/30 rounded-2xl p-5 mb-5"
        >
          {/* Rule name badge */}
          <div className="inline-block px-3 py-1 rounded-full bg-gold/10 border border-gold/30 mb-3">
            <span className="text-gold text-xs font-semibold tracking-wide">{card.title}</span>
          </div>

          {/* Rule explanation */}
          <p className="text-cream/90 text-sm leading-relaxed mb-5">{card.rule}</p>

          {/* Example */}
          <div className="bg-[#150030]/60 border border-gold/10 rounded-xl p-4">
            <p className="text-xs text-slate mb-2 uppercase tracking-wider">Beispiel</p>
            <div className="flex items-center gap-2">
              <p className="text-gold german-text text-lg font-semibold flex-1">{card.de}</p>
              <button onClick={() => speak(card.de)} className="p-1.5 rounded-lg hover:bg-white/5 transition-colors shrink-0">
                <Volume2 className="w-4 h-4 text-gold/60" />
              </button>
            </div>
            <p className="text-slate text-sm mt-1 italic">{card.en}</p>
          </div>
        </motion.div>

        <div className="flex gap-3">
          {teachIdx < teachCards.length - 1 ? (
            <button
              onClick={() => setTeachIdx(i => i + 1)}
              className="flex-1 py-3 bg-gold/20 border border-gold/50 rounded-lg text-gold font-semibold hover:bg-gold/30 transition-colors"
            >
              Nächste Regel →
            </button>
          ) : (
            <button
              onClick={() => setPhase('quiz')}
              className="flex-1 py-3 bg-gold/30 border border-gold rounded-lg text-gold font-bold hover:bg-gold/40 transition-colors"
            >
              Quiz starten ⚔️
            </button>
          )}
        </div>

        {/* Dot indicators */}
        <div className="flex justify-center gap-2 mt-4">
          {teachCards.map((_: any, i: number) => (
            <div key={i} className={`w-2 h-2 rounded-full transition-all ${i === teachIdx ? 'bg-gold' : 'bg-gold/20'}`} />
          ))}
        </div>
      </div>
    );
  }

  // ── QUIZ PHASE ──
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <span className="text-sm text-slate">Frage {currentIdx + 1}/{questions.length}</span>
        <span className="text-sm text-gold">Score: {score}</span>
      </div>

      {/* Rule hint badge */}
      <div className="inline-block px-3 py-1 rounded-full bg-gold/10 border border-gold/20 mb-3">
        <span className="text-gold/70 text-xs">{currentQ.ruleTitle}</span>
      </div>

      <div className="bg-[#0a0020]/50 border border-gold/20 rounded-xl p-4 mb-6">
        <p className="text-sm text-slate mb-2">{currentQ.prompt}</p>
        <div className="flex items-center gap-2">
          <p className="text-gold german-text text-xl font-semibold flex-1">{currentQ.sentence}</p>
          <button onClick={() => speak(currentQ.translation)} className="p-1.5 rounded-lg hover:bg-white/5 transition-colors shrink-0">
            <Volume2 className="w-4 h-4 text-gold/50" />
          </button>
        </div>
        <p className="text-slate text-sm mt-2 italic">{currentQ.translation}</p>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        {currentQ.options.map((opt: string, i: number) => {
          const isCorrect = opt === currentQ.correct;
          const isSelected = selected === opt;
          return (
            <motion.button
              key={i}
              whileTap={{ scale: 0.97 }}
              onClick={() => handleAnswer(opt)}
              disabled={selected !== null}
              className={`p-4 rounded-xl border text-center font-semibold german-text transition-all
                ${selected === null
                  ? 'bg-[#0a0020]/50 border-gold/20 hover:border-gold/60 hover:bg-gold/10 text-cream'
                  : isCorrect
                    ? 'bg-emerald-900/40 border-emerald-400/60 text-emerald-300'
                    : isSelected
                      ? 'bg-red-900/40 border-red-400/60 text-red-300'
                      : 'bg-[#0a0020]/30 border-slate/10 text-slate opacity-40'
                }
              `}
            >
              {opt}
              {selected !== null && isCorrect && <Check className="inline w-4 h-4 ml-1" />}
              {isSelected && !isCorrect && <X className="inline w-4 h-4 ml-1" />}
            </motion.button>
          );
        })}
      </div>

      {/* Explanation panel — shown after answer */}
      {selected !== null && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-xl border ${selected === currentQ.correct ? 'bg-emerald-900/20 border-emerald-500/30' : 'bg-red-900/20 border-red-500/30'}`}
        >
          <p className="text-xs font-semibold mb-1 uppercase tracking-wider text-slate">Warum?</p>
          <p className="text-sm text-cream/80 leading-relaxed">{currentQ.explanation}</p>
        </motion.div>
      )}
    </div>
  );
}

/* ─── WRITING TRIAL ─── */
function WritingTrial({ prompts, onComplete }: { prompts: string[], onComplete: (s: number, g: number) => void }) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [input, setInput] = useState('');
  const [score, setScore] = useState(0);
  const [checking, setChecking] = useState(false);
  const [feedback, setFeedback] = useState<{ errors: any[]; score: number; message: string } | null>(null);

  const checkWriting = async () => {
    if (!input.trim()) return;
    setChecking(true);

    try {
      const params = new URLSearchParams({
        text: input,
        language: 'de-DE',
        enabledOnly: 'false',
      });

      const res = await fetch('https://api.languagetool.org/v2/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params.toString(),
      });

      const data = await res.json();
      const errors = data.matches || [];
      const wordCount = input.trim().split(/\s+/).length;

      // Score: base points for writing + deductions for errors
      const baseScore = Math.min(wordCount * 4, 25);
      const errorDeduction = Math.min(errors.length * 4, 20);
      const roundScore = Math.max(baseScore - errorDeduction, 5);

      let message = '';
      if (errors.length === 0) message = 'Perfekt! Keine Fehler gefunden. 🏆';
      else if (errors.length <= 2) message = 'Gut gemacht! Ein paar kleine Fehler.';
      else message = 'Weiter üben! Schau dir die Hinweise unten an.';

      setFeedback({ errors, score: roundScore, message });
      setScore(s => s + roundScore);
    } catch {
      // Fallback if API fails — score by word count
      const wordCount = input.trim().split(/\s+/).length;
      const roundScore = Math.min(wordCount * 4, 25);
      setFeedback({ errors: [], score: roundScore, message: 'Grammatikprüfung nicht verfügbar. Punkte für Wortanzahl.' });
      setScore(s => s + roundScore);
    } finally {
      setChecking(false);
    }
  };

  const next = () => {
    if (currentIdx < prompts.length - 1) {
      setCurrentIdx(c => c + 1);
      setInput('');
      setFeedback(null);
    } else {
      const gold = Math.floor(score / 10);
      confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 }, colors: ['#FFD700', '#F5E6D3'] });
      onComplete(score, gold);
    }
  };

  // Highlight errors inline
  const getHighlightedText = () => {
    if (!feedback || feedback.errors.length === 0) return null;
    let result: React.ReactNode[] = [];
    let lastIdx = 0;

    const sorted = [...feedback.errors].sort((a, b) => a.offset - b.offset);
    sorted.forEach((err, i) => {
      if (err.offset > lastIdx) {
        result.push(<span key={`text-${i}`}>{input.slice(lastIdx, err.offset)}</span>);
      }
      result.push(
        <span key={`err-${i}`} className="bg-red-500/30 border-b-2 border-red-400 rounded px-0.5" title={err.message}>
          {input.slice(err.offset, err.offset + err.length)}
        </span>
      );
      lastIdx = err.offset + err.length;
    });
    if (lastIdx < input.length) result.push(<span key="tail">{input.slice(lastIdx)}</span>);
    return result;
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <span className="text-sm text-slate">Aufgabe {currentIdx + 1}/{prompts.length}</span>
        <span className="text-sm text-gold">Score: {score}</span>
      </div>

      <div className="bg-[#0a0020]/50 border border-gold/20 rounded-xl p-4 mb-4">
        <p className="text-xs text-slate uppercase tracking-wider mb-2">Schreibe auf Deutsch:</p>
        <p className="text-cream">{prompts[currentIdx]}</p>
      </div>

      {!feedback ? (
        <>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Deine Antwort auf Deutsch..."
            className="w-full h-32 bg-[#0a0020]/50 border border-gold/20 rounded-xl p-4
                       text-cream placeholder:text-slate/50 resize-none focus:border-gold/50
                       focus:outline-none transition-colors mb-4"
          />
          <button
            onClick={checkWriting}
            disabled={!input.trim() || checking}
            className="w-full py-3 bg-gold/20 border border-gold/50 rounded-lg text-gold
                       font-semibold hover:bg-gold/30 transition-colors disabled:opacity-30"
          >
            {checking ? 'Wird geprüft...' : 'Einreichen & Prüfen'}
          </button>
        </>
      ) : (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          {/* Result message */}
          <div className={`p-4 rounded-xl border mb-4 ${feedback.errors.length === 0 ? 'bg-emerald-900/20 border-emerald-500/30' : 'bg-yellow-900/20 border-yellow-500/30'}`}>
            <p className={`font-semibold mb-1 ${feedback.errors.length === 0 ? 'text-emerald-300' : 'text-yellow-300'}`}>{feedback.message}</p>
            <p className="text-xs text-slate">+{feedback.score} Punkte</p>
          </div>

          {/* Highlighted text */}
          {feedback.errors.length > 0 && (
            <div className="bg-[#0a0020]/50 border border-gold/20 rounded-xl p-4 mb-4">
              <p className="text-xs text-slate uppercase tracking-wider mb-2">Dein Text:</p>
              <p className="text-cream german-text leading-relaxed">{getHighlightedText()}</p>
            </div>
          )}

          {/* Error list */}
          {feedback.errors.length > 0 && (
            <div className="space-y-2 mb-4">
              {feedback.errors.slice(0, 4).map((err, i) => (
                <div key={i} className="bg-[#0a0020]/50 border border-red-500/20 rounded-lg p-3">
                  <div className="flex items-start gap-2">
                    <X className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm text-red-300 font-medium">
                        „{input.slice(err.offset, err.offset + err.length)}"
                        {err.replacements?.length > 0 && (
                          <span className="text-emerald-300 ml-2">→ „{err.replacements[0].value}"</span>
                        )}
                      </p>
                      <p className="text-xs text-slate mt-0.5">{err.message}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          <button
            onClick={next}
            className="w-full py-3 bg-gold/20 border border-gold/50 rounded-lg text-gold
                       font-semibold hover:bg-gold/30 transition-colors"
          >
            {currentIdx < prompts.length - 1 ? 'Nächste Aufgabe →' : 'Abschließen'}
          </button>
        </motion.div>
      )}
    </div>
  );
}

/* ─── UTILS ─── */
function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

function generateOptions(correct: any, pool: any[]): any[] {
  const wrong = pool.filter(w => w.en !== correct.en).slice(0, 3);
  return shuffleArray([correct, ...wrong]);
}

function calculateSimilarity(a: string, b: string): number {
  // Simple similarity based on matching words
  const wordsA = a.split(/\s+/);
  const wordsB = b.split(/\s+/);
  const matches = wordsA.filter(w => wordsB.includes(w)).length;
  return matches / Math.max(wordsA.length, wordsB.length);
}
