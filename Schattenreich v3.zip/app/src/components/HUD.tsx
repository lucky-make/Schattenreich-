import { Coins, Flame, Map, Gem, ShoppingBag, Settings } from 'lucide-react';
import { motion } from 'framer-motion';

interface HUDProps {
  xp: number;
  gold: number;
  level: number;
  streak: number;
  currentZone: number;
  onMap: () => void;
  onVault: () => void;
  onShop: () => void;
  onSettings: () => void;
}

export function HUD({ xp, gold, level, streak, currentZone, onMap, onVault, onShop, onSettings }: HUDProps) {
  const xpProgress = (xp % 500) / 500 * 100;
  
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-[#0a0020]/95 to-transparent backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Left - Level & XP */}
          <div className="flex items-center gap-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onMap}
              className="flex items-center gap-2 text-gold hover:text-gold/80 transition-colors"
            >
              <Map className="w-5 h-5" />
              <span className="text-sm font-bold hidden sm:inline" style={{ fontFamily: 'Cinzel, serif' }}>
                Schattenreich
              </span>
            </motion.button>
            
            <div className="hidden sm:flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-600 to-yellow-500 flex items-center justify-center text-sm font-bold text-[#0a0020]">
                {level}
              </div>
              <div className="flex flex-col w-24">
                <div className="h-2 bg-[#1a0a3e] rounded-full overflow-hidden border border-gold/20">
                  <motion.div
                    className="h-full bg-gradient-to-r from-amber-600 to-gold"
                    initial={{ width: 0 }}
                    animate={{ width: `${xpProgress}%` }}
                    transition={{ duration: 1, ease: 'easeOut' }}
                  />
                </div>
                <span className="text-xs text-slate/70">{xp % 500}/500 XP</span>
              </div>
            </div>
          </div>
          
          {/* Center - Current Zone */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate/60 hidden md:inline">Zone</span>
            <span className="text-sm font-bold text-gold">{currentZone}/120</span>
          </div>
          
          {/* Right - Stats & Menu */}
          <div className="flex items-center gap-3 md:gap-5">
            <div className="flex items-center gap-1.5" title="Gold">
              <Coins className="w-4 h-4 text-gold" />
              <span className="text-sm font-semibold text-gold hidden sm:inline">{gold}</span>
            </div>
            
            <div className="flex items-center gap-1.5" title="Streak">
              <Flame className="w-4 h-4 text-orange-500" />
              <span className="text-sm font-semibold text-orange-400 hidden sm:inline">{streak}</span>
            </div>
            
            <div className="flex items-center gap-2">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={onVault}
                className="p-2 rounded-lg hover:bg-white/5 transition-colors"
                title="Schatzkammer"
              >
                <Gem className="w-4 h-4 text-purple-400" />
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={onShop}
                className="p-2 rounded-lg hover:bg-white/5 transition-colors"
                title="Shop"
              >
                <ShoppingBag className="w-4 h-4 text-emerald-400" />
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={onSettings}
                className="p-2 rounded-lg hover:bg-white/5 transition-colors"
                title="Einstellungen"
              >
                <Settings className="w-4 h-4 text-slate" />
              </motion.button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
