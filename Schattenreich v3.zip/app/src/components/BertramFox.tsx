import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

interface BertramFoxProps {
  message: string;
}

export function BertramFox({ message }: BertramFoxProps) {
  const [isOpen, setIsOpen] = useState(true);
  const [currentMessage, setCurrentMessage] = useState(message);

  useEffect(() => {
    if (message !== currentMessage) {
      setIsOpen(true);
      setCurrentMessage(message);
    }
  }, [message, currentMessage]);

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            transition={{ type: 'spring', damping: 20 }}
            className="max-w-xs bg-gradient-to-br from-[#1a0a3e] to-[#2d1b4e] 
                       border border-gold/30 rounded-xl p-4 shadow-2xl 
                       shadow-gold/10 relative"
          >
            <button
              onClick={() => setIsOpen(false)}
              className="absolute top-2 right-2 text-slate/50 hover:text-cream transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
            <p className="text-sm text-cream/90 leading-relaxed pr-4 italic" style={{ fontFamily: 'EB Garamond, serif' }}>
              {currentMessage}
            </p>
            <div className="mt-2 text-xs text-gold/60 text-right" style={{ fontFamily: 'Cinzel, serif' }}>
              — Bertram
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 rounded-full bg-gradient-to-br from-amber-700 to-yellow-600 
                   border-2 border-gold/50 shadow-lg shadow-gold/20 
                   flex items-center justify-center hover:shadow-gold/40 transition-shadow"
      >
        <svg viewBox="0 0 24 24" className="w-8 h-8 text-gold" fill="currentColor">
          <path d="M12 2C8.5 2 5.5 4 4 7c-1.5 3-1 6.5 1 9l-1 3 3.5-1.5C9.5 18.5 11 19 12 19c4.5 0 8-3.5 8-8.5S16.5 2 12 2zm0 15c-1 0-2-.5-3-1l-2.5 1 .5-2C5.5 13 5 11 6 9c1-2 3-3.5 6-3.5s5 2 5 4.5S14 15 12 17z"/>
          <circle cx="9.5" cy="9.5" r="1" />
          <circle cx="14.5" cy="9.5" r="1" />
          <path d="M10.5 12.5c.5.5 2.5.5 3 0" stroke="currentColor" strokeWidth="0.5" fill="none" />
        </svg>
      </motion.button>
    </div>
  );
}
