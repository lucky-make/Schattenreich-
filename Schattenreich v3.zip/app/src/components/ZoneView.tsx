import { motion } from 'framer-motion';
import { BookOpen, Hammer, Headphones, Mic, Brain, PenTool, Shield, ArrowLeft, Lock, CheckCircle2, AlertTriangle } from 'lucide-react';
import { getZoneById } from '@/data/zones';
import type { TrialType } from '@/types/game';

interface ZoneViewProps {
  zoneId: number;
  completedTrials: string[];
  bossDefeated: boolean;
  needsRecap: boolean;
  canStartBoss: boolean;
  onStartTrial: (type: TrialType) => void;
  onStartRecap: () => void;
  onStartBoss: () => void;
  onBack: () => void;
}

const trialConfig: { type: TrialType; icon: React.ElementType; name: string; description: string; color: string }[] = [
  { type: 'lexicon', icon: BookOpen, name: 'Lexicon-Keller', description: 'Vokabellernen & Abfrage', color: 'text-blue-400' },
  { type: 'sentence', icon: Hammer, name: 'Satz-Schmiede', description: 'Satzbaumeister', color: 'text-amber-400' },
  { type: 'listening', icon: Headphones, name: 'Hör-Gewölbe', description: 'Diktat & Hörverstehen', color: 'text-purple-400' },
  { type: 'speaking', icon: Mic, name: 'Sprech-Halle', description: 'Sprachübung & Selbstbewertung', color: 'text-rose-400' },
  { type: 'grammar', icon: Brain, name: 'Grammatik-Keller', description: 'Grammatikprüfung', color: 'text-emerald-400' },
  { type: 'writing', icon: PenTool, name: 'Schreib-Gewölbe', description: 'Schreibübung & Vergleich', color: 'text-cyan-400' },
];

export function ZoneView({ zoneId, completedTrials, bossDefeated, needsRecap, canStartBoss, onStartTrial, onStartRecap, onStartBoss, onBack }: ZoneViewProps) {
  const zone = getZoneById(zoneId);
  if (!zone) return null;

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate hover:text-gold transition-colors mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="text-sm">Zurück zur Karte</span>
        </button>

        <div className="relative bg-gradient-to-br from-[#1a0a3e] to-[#0d0221] 
                        border border-gold/30 rounded-2xl p-6 md:p-8 overflow-hidden">
          {/* Background glow */}
          <div className="absolute top-0 right-0 w-64 h-64 rounded-full opacity-20 blur-3xl"
               style={{ backgroundColor: zone.color }} />
          
          <div className="relative z-10">
            <div className="flex items-start gap-4 mb-4">
              <span className="text-4xl md:text-5xl">{zone.emoji}</span>
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-1">
                  <h1 className="text-2xl md:text-3xl font-bold text-gold" style={{ fontFamily: 'Cinzel, serif' }}>
                    {zone.name}
                  </h1>
                  <span className="px-2 py-0.5 bg-gold/20 rounded-full text-xs text-gold font-semibold">
                    {zone.level}
                  </span>
                </div>
                <p className="text-slate">{zone.subtitle}</p>
              </div>
            </div>
            
            <div className="space-y-2 text-sm">
              <p className="text-cream/80">
                <span className="text-gold font-semibold">Grammatik:</span> {zone.grammarFocus}
              </p>
              <p className="text-cream/80">
                <span className="text-gold font-semibold">Vokabular:</span> {zone.vocabTheme}
              </p>
            </div>

            {/* Progress */}
            <div className="mt-4 flex items-center gap-2">
              <div className="flex-1 h-2 bg-[#0a0020] rounded-full overflow-hidden">
                <motion.div
                  className="h-full rounded-full"
                  style={{ backgroundColor: zone.color }}
                  initial={{ width: 0 }}
                  animate={{ width: `${(completedTrials.length / 6) * 100}%` }}
                  transition={{ duration: 0.8 }}
                />
              </div>
              <span className="text-xs text-slate">{completedTrials.length}/6 Prüfungen</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Recap Warning */}
      {needsRecap && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mb-6 bg-amber-900/20 border border-amber-500/30 rounded-xl p-4 
                     flex items-center gap-3"
        >
          <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-sm text-amber-200 font-semibold">Rückblick erforderlich</p>
            <p className="text-xs text-amber-200/70">Bestehe den Rückblick der vorherigen Zone, um fortzufahren.</p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onStartRecap}
            className="px-4 py-2 bg-amber-600/30 border border-amber-500/50 rounded-lg 
                       text-amber-200 text-sm hover:bg-amber-600/50 transition-colors"
          >
            Rückblick starten
          </motion.button>
        </motion.div>
      )}

      {/* Trials Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4 mb-8">
        {trialConfig.map((trial, idx) => {
          const isCompleted = completedTrials.includes(trial.type);
          const isLocked = needsRecap;
          
          return (
            <motion.button
              key={trial.type}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              whileHover={!isLocked ? { scale: 1.03, y: -2 } : {}}
              whileTap={!isLocked ? { scale: 0.97 } : {}}
              onClick={() => !isLocked && onStartTrial(trial.type)}
              disabled={isLocked}
              className={`relative p-4 md:p-6 rounded-xl border transition-all duration-300 text-left
                ${isCompleted
                  ? 'bg-emerald-900/20 border-emerald-500/40'
                  : isLocked
                    ? 'bg-[#0a0020]/40 border-slate/20 opacity-50 cursor-not-allowed'
                    : 'bg-[#1a0a3e]/60 border-gold/20 hover:border-gold/50 hover:shadow-lg hover:shadow-gold/10'
                }
              `}
            >
              <div className="flex items-start justify-between mb-3">
                <trial.icon className={`w-6 h-6 ${isCompleted ? 'text-emerald-400' : trial.color}`} />
                {isCompleted && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
                {isLocked && <Lock className="w-4 h-4 text-slate" />}
              </div>
              
              <h3 className={`font-semibold text-sm mb-1 ${isCompleted ? 'text-emerald-300' : 'text-cream'}`}>
                {trial.name}
              </h3>
              <p className="text-xs text-slate">{trial.description}</p>
              
              {isCompleted && (
                <div className="absolute inset-0 rounded-xl ring-1 ring-emerald-500/30 pointer-events-none" />
              )}
            </motion.button>
          );
        })}
      </div>

      {/* Boss Battle */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="text-center"
      >
        {bossDefeated ? (
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-emerald-900/30 border border-emerald-500/40 rounded-xl">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span className="text-emerald-300 font-semibold">Boss besiegt! Zone gemeistert.</span>
          </div>
        ) : (
          <motion.button
            whileHover={canStartBoss ? { scale: 1.05 } : {}}
            whileTap={canStartBoss ? { scale: 0.95 } : {}}
            onClick={canStartBoss ? onStartBoss : undefined}
            disabled={!canStartBoss}
            className={canStartBoss
              ? 'inline-flex items-center gap-3 px-8 py-4 rounded-xl border bg-gradient-to-r from-red-900/60 to-orange-900/60 border-red-500/50 text-red-200 hover:border-red-400 hover:shadow-lg hover:shadow-red-500/20 transition-all duration-300'
              : 'inline-flex items-center gap-3 px-8 py-4 rounded-xl border bg-[#0a0020]/40 border-slate/20 text-slate/50 cursor-not-allowed transition-all duration-300'
            }
          >
            <Shield className="w-6 h-6" />
            <div className="text-left">
              <p className="font-bold" style={{ fontFamily: 'Cinzel, serif' }}>
                {canStartBoss ? 'Boss herausfordern' : 'Boss verschlossen'}
              </p>
              <p className="text-xs opacity-70">
                {canStartBoss 
                  ? 'Mindestens 4 Prüfungen abgeschlossen'
                  : `${Math.max(0, 4 - completedTrials.length)} weitere Prüfungen nötig`
                }
              </p>
            </div>
          </motion.button>
        )}
      </motion.div>
    </div>
  );
}
