import { motion } from 'framer-motion';
import { Sparkles, Moon, ArrowRight } from 'lucide-react';

interface StartScreenProps {
  onStart: () => void;
}

export function StartScreen({ onStart }: StartScreenProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background gradient orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-900/20 rounded-full blur-3xl animate-pulse-slow" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-900/20 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '2s' }} />
      
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.2, ease: 'easeOut' }}
        className="text-center z-10 px-4"
      >
        {/* Logo / Title */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3, duration: 1 }}
          className="mb-8"
        >
          <div className="relative inline-block">
            <Moon className="w-20 h-20 text-gold mx-auto mb-4 animate-float" />
            <Sparkles className="w-8 h-8 text-gold absolute -top-2 -right-4 animate-pulse-slow" />
          </div>
        </motion.div>
        
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="text-5xl md:text-7xl font-bold text-gold text-shadow-gold mb-4 tracking-wide"
          style={{ fontFamily: 'Cinzel, serif' }}
        >
          Schattenreich
        </motion.h1>
        
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="text-xl md:text-2xl text-cream/80 mb-2 italic"
          style={{ fontFamily: 'EB Garamond, serif' }}
        >
          The Shadow Language
        </motion.p>
        
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.1, duration: 0.8 }}
          className="text-sm md:text-base text-slate mb-12 max-w-md mx-auto"
        >
          Ein episches Abenteuer durch 120 Tage deutscher Sprache. 
          Von A1 bis B2 – mit Bertram, dem Fuchs der Weisheit.
        </motion.p>
        
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.4, duration: 0.6 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onStart}
          className="group relative px-8 py-4 bg-gradient-to-r from-amber-700/80 to-yellow-600/80 rounded-full 
                     border border-gold/50 text-gold font-semibold text-lg
                     hover:border-gold hover:shadow-lg hover:shadow-gold/20
                     transition-all duration-300"
          style={{ fontFamily: 'Cinzel, serif' }}
        >
          <span className="flex items-center gap-3">
            Reise Beginnen
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </span>
          <div className="absolute inset-0 rounded-full bg-gold/10 opacity-0 group-hover:opacity-100 transition-opacity" />
        </motion.button>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.8, duration: 1 }}
          className="mt-12 text-xs text-slate/60"
        >
          <p>120 Zonen • 4000+ Wörter • 6 Prüfungstypen • 1 epische Reise</p>
        </motion.div>
      </motion.div>
      
      {/* Decorative elements */}
      <div className="absolute bottom-8 left-8 w-2 h-2 bg-gold rounded-full animate-pulse-slow" />
      <div className="absolute top-16 right-16 w-1 h-1 bg-cream rounded-full animate-pulse-slow" style={{ animationDelay: '1s' }} />
      <div className="absolute bottom-24 right-32 w-1.5 h-1.5 bg-slate rounded-full animate-pulse-slow" style={{ animationDelay: '2s' }} />
    </div>
  );
}
