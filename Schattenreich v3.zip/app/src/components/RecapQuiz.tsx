import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Check, X, Trophy, Volume2 } from 'lucide-react';
import { getReviewWords } from '@/data/zones';
import confetti from 'canvas-confetti';

interface RecapQuizProps {
  zoneId: number;
  onComplete: () => void;
  onBack: () => void;
}

export function RecapQuiz({ zoneId, onComplete, onBack }: RecapQuizProps) {
  const [currentQ, setCurrentQ] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);

  // Get review words from previous 5 zones
  const reviewWords = getReviewWords(zoneId, 15);
  
  // Create questions
  const questions = reviewWords.slice(0, 10).map((word) => {
    const wrongOptions = reviewWords.filter(w => w.en !== word.en).slice(0, 3);
    const options = [word, ...wrongOptions].sort(() => Math.random() - 0.5);
    return {
      word,
      options,
      correctIdx: options.findIndex(o => o.en === word.en),
    };
  });

  const handleAnswer = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);

    const isCorrect = idx === questions[currentQ].correctIdx;
    if (isCorrect) setScore(s => s + 10);

    setTimeout(() => {
      if (currentQ < questions.length - 1) {
        setCurrentQ(c => c + 1);
        setSelected(null);
      } else {
        setShowResult(true);
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 }, colors: ['#FFD700', '#F5E6D3'] });
        setTimeout(() => onComplete(), 2000);
      }
    }, 1000);
  };

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'de-DE';
    utterance.rate = 0.85;
    window.speechSynthesis.speak(utterance);
  };

  if (showResult) {
    return (
      <div className="max-w-xl mx-auto text-center py-20">
        <Trophy className="w-16 h-16 text-gold mx-auto mb-4" />
        <h2 className="text-3xl font-bold text-gold mb-2">Rückblick bestanden!</h2>
        <p className="text-cream/80 mb-2">Score: {score}/100</p>
        <p className="text-sm text-slate">Die vorherigen Zonen sind nun freigeschaltet.</p>
      </div>
    );
  }

  const q = questions[currentQ];

  return (
    <div className="max-w-xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={onBack} className="p-2 rounded-lg hover:bg-white/5 transition-colors">
          <ArrowLeft className="w-5 h-5 text-slate" />
        </button>
        <h2 className="text-xl font-bold text-gold" style={{ fontFamily: 'Cinzel, serif' }}>
          Täglicher Rückblick
        </h2>
      </div>

      <div className="bg-gradient-to-br from-[#1a0a3e] to-[#0d0221] border border-gold/20 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-6">
          <span className="text-sm text-slate">Frage {currentQ + 1}/{questions.length}</span>
          <span className="text-sm text-gold">Score: {score}</span>
        </div>

        <div className="text-center mb-8">
          <p className="text-sm text-slate mb-2">Was bedeutet:</p>
          <div className="flex items-center justify-center gap-3">
            <p className="text-2xl font-bold text-gold german-text">
              {q.word.article ? `${q.word.article} ` : ''}{q.word.de}
            </p>
            <button onClick={() => speak(q.word.de)} className="p-2 rounded-lg hover:bg-white/5">
              <Volume2 className="w-5 h-5 text-gold" />
            </button>
          </div>
        </div>

        <div className="space-y-3">
          {q.options.map((opt, i) => (
            <motion.button
              key={i}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleAnswer(i)}
              disabled={selected !== null}
              className={`w-full p-4 rounded-xl border text-left transition-all
                ${selected === null
                  ? 'bg-[#0a0020]/50 border-gold/20 hover:border-gold/50'
                  : i === q.correctIdx
                    ? 'bg-emerald-900/30 border-emerald-500/50'
                    : selected === i
                      ? 'bg-red-900/30 border-red-500/50'
                      : 'bg-[#0a0020]/30 border-slate/20 opacity-50'
                }
              `}
            >
              <span className="text-cream">{opt.en}</span>
              {selected !== null && i === q.correctIdx && (
                <Check className="inline w-4 h-4 text-emerald-400 ml-2" />
              )}
              {selected === i && i !== q.correctIdx && (
                <X className="inline w-4 h-4 text-red-400 ml-2" />
              )}
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}
