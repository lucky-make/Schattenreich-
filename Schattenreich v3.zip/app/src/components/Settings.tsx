import { motion } from 'framer-motion';
import { ArrowLeft, Volume2, VolumeX, Mic, AlertTriangle, RotateCcw } from 'lucide-react';

interface SettingsProps {
  settings: { sound: boolean; voice: boolean; difficulty: 'normal' | 'hard' };
  onUpdate: (s: Partial<{ sound: boolean; voice: boolean; difficulty: 'normal' | 'hard' }>) => void;
  onReset: () => void;
  onBack: () => void;
}

export function Settings({ settings, onUpdate, onReset, onBack }: SettingsProps) {
  return (
    <div className="max-w-xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <button onClick={onBack} className="p-2 rounded-lg hover:bg-white/5 transition-colors">
          <ArrowLeft className="w-5 h-5 text-slate" />
        </button>
        <h1 className="text-3xl font-bold text-gold" style={{ fontFamily: 'Cinzel, serif' }}>
          Einstellungen
        </h1>
      </div>

      <div className="space-y-4">
        {/* Sound Toggle */}
        <div className="bg-[#1a0a3e]/60 border border-gold/20 rounded-xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {settings.sound ? <Volume2 className="w-5 h-5 text-gold" /> : <VolumeX className="w-5 h-5 text-slate" />}
            <div>
              <p className="font-semibold text-cream">Sound-Effekte</p>
              <p className="text-xs text-slate">Töne bei Erfolg und Fehler</p>
            </div>
          </div>
          <button
            onClick={() => onUpdate({ sound: !settings.sound })}
            className={`w-12 h-6 rounded-full transition-colors relative
              ${settings.sound ? 'bg-gold/40' : 'bg-slate/30'}
            `}
          >
            <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-gold transition-transform
              ${settings.sound ? 'translate-x-6' : 'translate-x-0.5'}
            `} />
          </button>
        </div>

        {/* Voice Toggle */}
        <div className="bg-[#1a0a3e]/60 border border-gold/20 rounded-xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Mic className={`w-5 h-5 ${settings.voice ? 'text-gold' : 'text-slate'}`} />
            <div>
              <p className="font-semibold text-cream">Sprachausgabe</p>
              <p className="text-xs text-slate">TTS für deutsche Vokabeln</p>
            </div>
          </div>
          <button
            onClick={() => onUpdate({ voice: !settings.voice })}
            className={`w-12 h-6 rounded-full transition-colors relative
              ${settings.voice ? 'bg-gold/40' : 'bg-slate/30'}
            `}
          >
            <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-gold transition-transform
              ${settings.voice ? 'translate-x-6' : 'translate-x-0.5'}
            `} />
          </button>
        </div>

        {/* Difficulty */}
        <div className="bg-[#1a0a3e]/60 border border-gold/20 rounded-xl p-4">
          <p className="font-semibold text-cream mb-3">Schwierigkeit</p>
          <div className="flex gap-3">
            <button
              onClick={() => onUpdate({ difficulty: 'normal' })}
              className={`flex-1 py-2 rounded-lg border text-sm font-semibold transition-all
                ${settings.difficulty === 'normal'
                  ? 'bg-gold/20 border-gold/50 text-gold'
                  : 'bg-[#0a0020]/50 border-slate/20 text-slate hover:border-gold/30'
                }
              `}
            >
              Normal
            </button>
            <button
              onClick={() => onUpdate({ difficulty: 'hard' })}
              className={`flex-1 py-2 rounded-lg border text-sm font-semibold transition-all
                ${settings.difficulty === 'hard'
                  ? 'bg-red-900/30 border-red-500/50 text-red-300'
                  : 'bg-[#0a0020]/50 border-slate/20 text-slate hover:border-red-500/30'
                }
              `}
            >
              Schwer
            </button>
          </div>
        </div>

        {/* Reset */}
        <motion.div
          whileHover={{ scale: 1.01 }}
          className="bg-red-900/20 border border-red-500/30 rounded-xl p-4 flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400" />
            <div>
              <p className="font-semibold text-red-300">Fortschritt zurücksetzen</p>
              <p className="text-xs text-red-300/70">Alle Daten werden gelöscht. Nicht rückgängig!</p>
            </div>
          </div>
          <button
            onClick={() => {
              if (confirm('Bist du sicher? Alle Fortschritte gehen verloren.')) {
                onReset();
              }
            }}
            className="px-4 py-2 bg-red-900/30 border border-red-500/50 rounded-lg 
                       text-red-300 text-sm font-semibold hover:bg-red-900/50 transition-colors
                       flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Reset
          </button>
        </motion.div>
      </div>
    </div>
  );
}
