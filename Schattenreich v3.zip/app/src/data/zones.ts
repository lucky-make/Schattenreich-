import type { Zone, VocabWord, GrammarRule, SentenceParts, BossQuestion } from '@/types/game';
import { vocabPools } from './vocabPools';

// Zone metadata
const zoneMeta = [
  { id: 1, name: "Das stille Tor", subtitle: "Greetings & Basic Sentences", level: "A1.1", emoji: "🌙", color: "#4a1942", grammarFocus: "Verb second, W-questions, yes/no questions, nicht", vocabTheme: "greetings" },
  { id: 2, name: "Der Familienwald", subtitle: "Family & Colors", level: "A1.1", emoji: "🌲", color: "#2d5a3d", grammarFocus: "Noun genders, indefinite article, predicative adjectives, possessive pronouns", vocabTheme: "family" },
  { id: 3, name: "Das Haus der tausend Räume", subtitle: "Rooms & Daily Life", level: "A1.1", emoji: "🏠", color: "#5a4a3a", grammarFocus: "Present tense, stem-changing verbs, separable verbs", vocabTheme: "rooms" },
  { id: 4, name: "Der kulinarische Markt", subtitle: "Food & Shopping", level: "A1.1", emoji: "🍞", color: "#8b4513", grammarFocus: "Accusative case, accusative prepositions, möchten, kein", vocabTheme: "food" },
  { id: 5, name: "Die Eisenstadt", subtitle: "City & Transport", level: "A1.1", emoji: "🏙️", color: "#4a5568", grammarFocus: "Dative case, dative prepositions, two-way prepositions", vocabTheme: "city" },
  { id: 6, name: "Die Kristallschule", subtitle: "School & Learning", level: "A1.2", emoji: "🏫", color: "#6b5b95", grammarFocus: "Adjective endings (nominative), weil + verb at end, wollen", vocabTheme: "school" },
  { id: 7, name: "Das Zeitreich", subtitle: "Time & Weather", level: "A1.2", emoji: "⏰", color: "#d4a574", grammarFocus: "Temporal prepositions, adverbs of frequency, werden + infinitive", vocabTheme: "time" },
  { id: 8, name: "Der Silberne Marktplatz", subtitle: "Shopping & Money", level: "A1.2", emoji: "🛍️", color: "#c0c0c0", grammarFocus: "Comparative, superlative, indirect speech, um...zu", vocabTheme: "shopping" },
  { id: 9, name: "Der Nebelmoor", subtitle: "Environment", level: "A2.1", emoji: "🌫️", color: "#2f4f4f", grammarFocus: "Konjunktiv II (würde), passive voice, genitive", vocabTheme: "environment" },
  { id: 10, name: "Die Traumfabrik", subtitle: "Jobs & Career", level: "A2.1", emoji: "💼", color: "#8b7355", grammarFocus: "Konjunktiv II, conditional clauses, reflexive verbs", vocabTheme: "jobs" },
  { id: 11, name: "Das Stürmische Meer", subtitle: "Travel & Adventure", level: "A2.1", emoji: "🌊", color: "#1e3a5f", grammarFocus: "Plusquamperfekt, participle as adjective, sodass", vocabTheme: "travel" },
  { id: 12, name: "Der Philosophenturm", subtitle: "Opinions & Debate", level: "A2.1", emoji: "🗼", color: "#4a6741", grammarFocus: "Extended participial phrase, discourse connectors", vocabTheme: "adjectives" },
  { id: 13, name: "Die Schwarze Bibliothek", subtitle: "Literature & Art", level: "A2.2", emoji: "📚", color: "#1a1a2e", grammarFocus: "Subjunctive II complex, passive with modals, es", vocabTheme: "media" },
  { id: 14, name: "Die Sprachschmiede", subtitle: "Idioms & Nuances", level: "A2.2", emoji: "🔨", color: "#5c4033", grammarFocus: "Double infinitive, Zustandspassiv, modal particles", vocabTheme: "greetings" },
  { id: 15, name: "Der Silberne Horizont", subtitle: "Globalization", level: "A2.2", emoji: "🌍", color: "#708090", grammarFocus: "Genitive chains, subjunctive distancing", vocabTheme: "environment" },
  { id: 16, name: "Das Ewige Schattenreich", subtitle: "A1-A2 Review", level: "A2.2", emoji: "👑", color: "#2c003e", grammarFocus: "All tenses review, register switching", vocabTheme: "greetings" },
  { id: 17, name: "Der Uhrturm", subtitle: "Time & Schedule", level: "A2.1", emoji: "🕐", color: "#8b7d6b", grammarFocus: "Telling time, temporal adverbs, separable verbs review", vocabTheme: "time" },
  { id: 18, name: "Das Verkehrsmuseum", subtitle: "Vehicles & Travel", level: "A2.1", emoji: "🚗", color: "#6b5b4f", grammarFocus: "Two-way prepositions (movement), driving terms", vocabTheme: "city" },
  { id: 19, name: "Der Postpalast", subtitle: "Mail & Communication", level: "A2.1", emoji: "📮", color: "#7b68ee", grammarFocus: "Dative verbs, personal pronouns dative", vocabTheme: "greetings" },
  { id: 20, name: "Das Modeatelier", subtitle: "Clothing & Fashion", level: "A2.1", emoji: "👗", color: "#dda0dd", grammarFocus: "Adjective endings (accusative), clothing verbs", vocabTheme: "shopping" },
  { id: 21, name: "Die Tierhandlung", subtitle: "Animals & Pets", level: "A2.1", emoji: "🐾", color: "#556b2f", grammarFocus: "Adjective endings (dative), animal comparisons", vocabTheme: "animals" },
  { id: 22, name: "Der Sportplatz", subtitle: "Sports & Hobbies", level: "A2.1", emoji: "⚽", color: "#228b22", grammarFocus: "Modal verbs, gern/lieber/am liebsten", vocabTheme: "sports" },
  { id: 23, name: "Das Krankenhaus", subtitle: "Health & Body", level: "A2.1", emoji: "🏥", color: "#dc143c", grammarFocus: "Reflexive verbs, body parts", vocabTheme: "body" },
  { id: 24, name: "Der Wochenmarkt", subtitle: "Market & Shopping", level: "A2.2", emoji: "🥬", color: "#8fbc8f", grammarFocus: "Verbs with fixed prepositions, food adjectives", vocabTheme: "food" },
  { id: 25, name: "Die Wohngemeinschaft", subtitle: "Shared Living", level: "A2.2", emoji: "🏘️", color: "#bc8f8f", grammarFocus: "Prepositions of place, describing rooms", vocabTheme: "rooms" },
  { id: 26, name: "Das Filmtheater", subtitle: "Cinema & Film", level: "A2.2", emoji: "🎬", color: "#483d8b", grammarFocus: "Relative clauses, film genres", vocabTheme: "media" },
  { id: 27, name: "Die Bergwanderung", subtitle: "Mountains & Hiking", level: "A2.2", emoji: "⛰️", color: "#8b7355", grammarFocus: "Comparative with so...wie, als, je...desto", vocabTheme: "nature" },
  { id: 28, name: "Der Geburtstagskalender", subtitle: "Birthdays", level: "A2.2", emoji: "🎂", color: "#ff69b4", grammarFocus: "Ordinal numbers, dative with dates", vocabTheme: "family" },
  { id: 29, name: "Das Kochstudio", subtitle: "Cooking & Recipes", level: "A2.2", emoji: "🍳", color: "#ff6347", grammarFocus: "Imperative, separable verbs with imperative", vocabTheme: "food" },
  { id: 30, name: "Die Bibliothek der Schatten", subtitle: "Reading & Books", level: "A2.2", emoji: "📖", color: "#2f4f4f", grammarFocus: "Subordinate clauses (dass), indirect questions", vocabTheme: "media" },
  { id: 31, name: "Der Stadtpark", subtitle: "Park & Leisure", level: "B1.1", emoji: "🌳", color: "#228b22", grammarFocus: "Infinitive with zu, park activities", vocabTheme: "nature" },
  { id: 32, name: "Das Internetcafé", subtitle: "Technology", level: "B1.1", emoji: "💻", color: "#4682b4", grammarFocus: "Prepositions with dative and accusative", vocabTheme: "technology" },
  { id: 33, name: "Der Flughafen", subtitle: "Airports & Flights", level: "B1.1", emoji: "✈️", color: "#87ceeb", grammarFocus: "Direction prepositions, travel verbs", vocabTheme: "travel" },
  { id: 34, name: "Das Telefonat", subtitle: "Phone & Messaging", level: "B1.1", emoji: "📞", color: "#ff8c00", grammarFocus: "Pronouns dative, telephone phrases", vocabTheme: "technology" },
  { id: 35, name: "Die Waschküche", subtitle: "Laundry & Cleaning", level: "B1.1", emoji: "🧺", color: "#b0c4de", grammarFocus: "Two-way prepositions with verbs", vocabTheme: "rooms" },
  { id: 36, name: "Das Klassenzimmer", subtitle: "Classroom & Learning", level: "B1.1", emoji: "🎓", color: "#8b4513", grammarFocus: "Indirect questions, school verbs", vocabTheme: "school" },
  { id: 37, name: "Die Straßenkarte", subtitle: "City Navigation", level: "B1.1", emoji: "🗺️", color: "#556b2f", grammarFocus: "Prepositions + genitive, complex directions", vocabTheme: "city" },
  { id: 38, name: "Der Kleiderschrank", subtitle: "Wardrobe & Style", level: "B1.1", emoji: "👔", color: "#800080", grammarFocus: "Adjective endings (indefinite article)", vocabTheme: "shopping" },
  { id: 39, name: "Die Festung der Freundschaft", subtitle: "Friendship", level: "B1.2", emoji: "🤝", color: "#daa520", grammarFocus: "Connectors (und, aber, oder, deshalb, trotzdem)", vocabTheme: "family" },
  { id: 40, name: "Der Weinkeller", subtitle: "Wine & Dining", level: "B1.2", emoji: "🍷", color: "#722f37", grammarFocus: "Subordinate clauses (weil, da), wine terms", vocabTheme: "food" },
  { id: 41, name: "Das Hotel am Meer", subtitle: "Holidays", level: "B1.2", emoji: "🏨", color: "#4169e1", grammarFocus: "Simple past (Präteritum) of sein/haben", vocabTheme: "travel" },
  { id: 42, name: "Der Fahrradweg", subtitle: "Cycling", level: "B1.2", emoji: "🚴", color: "#32cd32", grammarFocus: "Connectors (weder...noch, sowohl...als auch)", vocabTheme: "sports" },
  { id: 43, name: "Der Hörsaal", subtitle: "University", level: "B1.2", emoji: "🎓", color: "#4b0082", grammarFocus: "Prepositions + accusative, university vocabulary", vocabTheme: "school" },
  { id: 44, name: "Das Fotostudio", subtitle: "Photography", level: "B1.2", emoji: "📷", color: "#696969", grammarFocus: "Relative clauses (dative, prepositions + relative)", vocabTheme: "technology" },
  { id: 45, name: "Die Möbelwerkstatt", subtitle: "Furniture", level: "B1.2", emoji: "🛋️", color: "#8b4513", grammarFocus: "Adjective endings (all cases indefinite)", vocabTheme: "rooms" },
  { id: 46, name: "Das Fest der Laternen", subtitle: "Festivals", level: "B1.2", emoji: "🏮", color: "#ff4500", grammarFocus: "Review: all cases", vocabTheme: "time" },
  { id: 47, name: "Die Brücke der Entscheidungen", subtitle: "Decisions", level: "B1.1", emoji: "🌉", color: "#4682b4", grammarFocus: "Subordinate clauses (obwohl, bevor, nachdem, seit, bis)", vocabTheme: "feelings" },
  { id: 48, name: "Der Konferenzraum", subtitle: "Business", level: "B1.1", emoji: "🏢", color: "#2f4f4f", grammarFocus: "Passive voice (Präsens), impersonal passive", vocabTheme: "jobs" },
  { id: 49, name: "Die Wetterwarte", subtitle: "Weather", level: "B1.1", emoji: "🌤️", color: "#87cefa", grammarFocus: "Connectors (cause and effect)", vocabTheme: "time" },
  { id: 50, name: "Das Tonstudio", subtitle: "Music", level: "B1.1", emoji: "🎵", color: "#9932cc", grammarFocus: "Relative clauses with prepositions", vocabTheme: "hobbies" },
  { id: 51, name: "Die Kunstgalerie", subtitle: "Art", level: "B1.1", emoji: "🎨", color: "#ff6347", grammarFocus: "Adjective endings (all articles)", vocabTheme: "media" },
  { id: 52, name: "Das Rathaus", subtitle: "Bureaucracy", level: "B1.1", emoji: "🏛️", color: "#708090", grammarFocus: "Konjunktiv II (polite requests), formal letters", vocabTheme: "jobs" },
  { id: 53, name: "Der Tiergarten", subtitle: "Zoo", level: "B1.1", emoji: "🦁", color: "#daa520", grammarFocus: "Infinitive constructions (statt zu, ohne zu, um zu)", vocabTheme: "animals" },
  { id: 54, name: "Die Redaktion", subtitle: "News", level: "B1.2", emoji: "📰", color: "#a9a9a9", grammarFocus: "Reported speech (Konjunktiv I)", vocabTheme: "media" },
  { id: 55, name: "Die Gärtnerei", subtitle: "Gardening", level: "B1.2", emoji: "🌱", color: "#228b22", grammarFocus: "Future I and II, probability", vocabTheme: "nature" },
  { id: 56, name: "Das Theater am Abgrund", subtitle: "Theatre", level: "B1.2", emoji: "🎭", color: "#8b0000", grammarFocus: "Passive voice (Präteritum), passive with modals", vocabTheme: "hobbies" },
  { id: 57, name: "Die Messehalle", subtitle: "Trade Fairs", level: "B1.2", emoji: "🏗️", color: "#cd853f", grammarFocus: "Participles as adjectives", vocabTheme: "shopping" },
  { id: 58, name: "Die Küstenstraße", subtitle: "Coast", level: "B1.2", emoji: "🌊", color: "#4682b4", grammarFocus: "Prepositions + genitive", vocabTheme: "nature" },
  { id: 59, name: "Das Gewölbe der Erinnerungen", subtitle: "Memories", level: "B1.2", emoji: "💭", color: "#6a5acd", grammarFocus: "Plusquamperfekt, temporal clauses", vocabTheme: "feelings" },
  { id: 60, name: "Die Start-up-Garage", subtitle: "Start-ups", level: "B1.2", emoji: "🚀", color: "#ff4500", grammarFocus: "Nominalization, business vocabulary", vocabTheme: "jobs" },
  { id: 61, name: "Der Wanderweg", subtitle: "Hiking", level: "B2.1", emoji: "🥾", color: "#8b7355", grammarFocus: "Two-part connectors", vocabTheme: "nature" },
  { id: 62, name: "Das Synchronstudio", subtitle: "Dubbing", level: "B2.1", emoji: "🎙️", color: "#4a6741", grammarFocus: "lassen + infinitive", vocabTheme: "media" },
  { id: 63, name: "Der Flohmarkt", subtitle: "Flea Markets", level: "B2.1", emoji: "🏺", color: "#d2691e", grammarFocus: "Verbs with prepositional objects", vocabTheme: "shopping" },
  { id: 64, name: "Das Observatorium", subtitle: "Astronomy", level: "B2.1", emoji: "🔭", color: "#191970", grammarFocus: "Future I for assumptions, particles", vocabTheme: "nature" },
  { id: 65, name: "Die Pralinenfabrik", subtitle: "Chocolate", level: "B2.1", emoji: "🍫", color: "#8b4513", grammarFocus: "Adjective endings (comparative/superlative)", vocabTheme: "food" },
  { id: 66, name: "Die Wohnungsbesichtigung", subtitle: "Apartments", level: "B2.1", emoji: "🔑", color: "#daa520", grammarFocus: "Relative clauses (all cases incl. genitive)", vocabTheme: "rooms" },
  { id: 67, name: "Das Sportstadion", subtitle: "Sports Events", level: "B2.1", emoji: "🏟️", color: "#228b22", grammarFocus: "Connectors (je...desto, als ob, als wenn)", vocabTheme: "sports" },
  { id: 68, name: "Die Schneiderwerkstatt", subtitle: "Tailoring", level: "B2.1", emoji: "✂️", color: "#800080", grammarFocus: "lassen + infinitive", vocabTheme: "shopping" },
  { id: 69, name: "Der Weihnachtsmarkt", subtitle: "Christmas", level: "B2.1", emoji: "🎄", color: "#dc143c", grammarFocus: "Passiv Perfekt, passive alternatives", vocabTheme: "time" },
  { id: 70, name: "Das Café der Dichter", subtitle: "Poetry", level: "B2.1", emoji: "☕", color: "#8b4513", grammarFocus: "Modal verbs (subjective meaning)", vocabTheme: "hobbies" },
  { id: 71, name: "Der Flusshafen", subtitle: "Rivers", level: "B2.1", emoji: "⚓", color: "#4682b4", grammarFocus: "Prepositions (temporal)", vocabTheme: "nature" },
  { id: 72, name: "Die Botschaft", subtitle: "Diplomacy", level: "B2.2", emoji: "🏛️", color: "#ffd700", grammarFocus: "Formal letter writing", vocabTheme: "jobs" },
  { id: 73, name: "Der Doktorhut", subtitle: "Academia", level: "B2.2", emoji: "🎓", color: "#000080", grammarFocus: "Nominalization, academic vocabulary", vocabTheme: "school" },
  { id: 74, name: "Der Maskenball", subtitle: "Masquerade", level: "B2.2", emoji: "🎭", color: "#4b0082", grammarFocus: "Konjunktiv II, hypotheticals", vocabTheme: "feelings" },
  { id: 75, name: "Das Aquarium", subtitle: "Marine", level: "B2.2", emoji: "🐠", color: "#00ced1", grammarFocus: "Prepositions (causal)", vocabTheme: "animals" },
  { id: 76, name: "Das Kino der Träume", subtitle: "Film Dreams", level: "B2.2", emoji: "🎬", color: "#2c003e", grammarFocus: "Review: all subordinate clauses", vocabTheme: "media" },
  { id: 77, name: "Die Sternwarte", subtitle: "Astronomy", level: "B2.1", emoji: "🔭", color: "#191970", grammarFocus: "Modal particles", vocabTheme: "nature" },
  { id: 78, name: "Der Hochzeitssaal", subtitle: "Weddings", level: "B2.1", emoji: "💒", color: "#ff69b4", grammarFocus: "Relative clauses with prepositions + was", vocabTheme: "family" },
  { id: 79, name: "Die Börse", subtitle: "Finance", level: "B2.1", emoji: "📈", color: "#006400", grammarFocus: "Nominalization chains", vocabTheme: "jobs" },
  { id: 80, name: "Die Baustelle", subtitle: "Construction", level: "B2.1", emoji: "🏗️", color: "#ff8c00", grammarFocus: "Passive with modal verbs", vocabTheme: "city" },
  { id: 81, name: "Das Atelier des Malers", subtitle: "Painting", level: "B2.1", emoji: "🎨", color: "#da70d6", grammarFocus: "Extended participial attributes", vocabTheme: "hobbies" },
  { id: 82, name: "Die Klimakonferenz", subtitle: "Climate", level: "B2.1", emoji: "🌍", color: "#228b22", grammarFocus: "Subjunctive I (full paradigm)", vocabTheme: "environment" },
  { id: 83, name: "Der Gerichtssaal", subtitle: "Law", level: "B2.1", emoji: "⚖️", color: "#4a4a4a", grammarFocus: "Prepositions (concessive)", vocabTheme: "jobs" },
  { id: 84, name: "Die Druckerei", subtitle: "Printing", level: "B2.1", emoji: "📰", color: "#696969", grammarFocus: "Subjunctive II for unreal comparisons", vocabTheme: "technology" },
  { id: 85, name: "Der Psychologensessel", subtitle: "Psychology", level: "B2.1", emoji: "🛋️", color: "#8b4513", grammarFocus: "Subjunctive II in complex conditionals", vocabTheme: "feelings" },
  { id: 86, name: "Das Opernhaus", subtitle: "Opera", level: "B2.1", emoji: "🎭", color: "#8b0000", grammarFocus: "Complex connectors", vocabTheme: "hobbies" },
  { id: 87, name: "Die Forschungsstation", subtitle: "Research", level: "B2.1", emoji: "🔬", color: "#4682b4", grammarFocus: "Advanced nominalization, scientific verbs", vocabTheme: "school" },
  { id: 88, name: "Der Technik-Campus", subtitle: "Technology", level: "B2.1", emoji: "💻", color: "#00bfff", grammarFocus: "Prepositions (consecutive)", vocabTheme: "technology" },
  { id: 89, name: "Das Spielkasino", subtitle: "Gaming", level: "B2.1", emoji: "🎰", color: "#dc143c", grammarFocus: "Subjunctive II for wishes", vocabTheme: "feelings" },
  { id: 90, name: "Die Luftbrücke", subtitle: "Aviation", level: "B2.1", emoji: "✈️", color: "#87ceeb", grammarFocus: "Gerundive", vocabTheme: "travel" },
  { id: 91, name: "Der Zeitungskiosk", subtitle: "Journalism", level: "B2.2", emoji: "📰", color: "#a52a2a", grammarFocus: "Connectors (restrictive)", vocabTheme: "media" },
  { id: 92, name: "Das Tanzstudio", subtitle: "Dance", level: "B2.2", emoji: "💃", color: "#ff1493", grammarFocus: "Subjunctive II for polite suggestions", vocabTheme: "hobbies" },
  { id: 93, name: "Die Silbermine", subtitle: "Mining", level: "B2.2", emoji: "⛏️", color: "#c0c0c0", grammarFocus: "Prepositions (final)", vocabTheme: "jobs" },
  { id: 94, name: "Der Buchverlag", subtitle: "Publishing", level: "B2.2", emoji: "📚", color: "#8b4513", grammarFocus: "Discourse connectors", vocabTheme: "media" },
  { id: 95, name: "Die Filmhochschule", subtitle: "Film School", level: "B2.2", emoji: "🎥", color: "#4b0082", grammarFocus: "Subjunctive II in past", vocabTheme: "media" },
  { id: 96, name: "Das Bundeskanzleramt", subtitle: "Politics", level: "B2.2", emoji: "🏛️", color: "#000080", grammarFocus: "Participles as nouns", vocabTheme: "jobs" },
  { id: 97, name: "Die Apotheke zum Goldenen Löwen", subtitle: "Pharmacy", level: "B2.2", emoji: "💊", color: "#ffd700", grammarFocus: "Prepositions (modal)", vocabTheme: "body" },
  { id: 98, name: "Der Antiquitätenladen", subtitle: "Antiques", level: "B2.2", emoji: "🏺", color: "#8b7355", grammarFocus: "Relative clauses with wer/wen/wem/wessen", vocabTheme: "shopping" },
  { id: 99, name: "Das Luxushotel", subtitle: "Luxury", level: "B2.2", emoji: "🏨", color: "#daa520", grammarFocus: "Registers (formal vs. informal)", vocabTheme: "travel" },
  { id: 100, name: "Die Philosophenschule", subtitle: "Philosophy", level: "B2.2", emoji: "🏛️", color: "#4a6741", grammarFocus: "Advanced participle constructions", vocabTheme: "feelings" },
  { id: 101, name: "Der Jazzkeller", subtitle: "Jazz", level: "B2.2", emoji: "🎷", color: "#4a1942", grammarFocus: "Compound adjectives", vocabTheme: "hobbies" },
  { id: 102, name: "Die Waldschule", subtitle: "Ecology", level: "B2.2", emoji: "🌲", color: "#228b22", grammarFocus: "Prepositions (instrumental)", vocabTheme: "nature" },
  { id: 103, name: "Die Raumstation", subtitle: "Space", level: "B2.2", emoji: "🚀", color: "#1a1a2e", grammarFocus: "Prepositions (adversative)", vocabTheme: "nature" },
  { id: 104, name: "Die Kunstakademie", subtitle: "Art Criticism", level: "B2.2", emoji: "🎨", color: "#ff6347", grammarFocus: "Subjunctive II in indirect speech", vocabTheme: "media" },
  { id: 105, name: "Das Weingut", subtitle: "Viticulture", level: "B2.2", emoji: "🍇", color: "#722f37", grammarFocus: "Participles with zu", vocabTheme: "food" },
  { id: 106, name: "Die Denkfabrik", subtitle: "Think Tanks", level: "B2.2", emoji: "🧠", color: "#4a4a4a", grammarFocus: "Nominalization of participle phrases", vocabTheme: "jobs" },
  { id: 107, name: "Die Schiffswerft", subtitle: "Shipbuilding", level: "B2.2", emoji: "⚓", color: "#4682b4", grammarFocus: "Prepositions (distributive)", vocabTheme: "nature" },
  { id: 108, name: "Das Modehaus", subtitle: "Fashion Design", level: "B2.2", emoji: "👗", color: "#ff1493", grammarFocus: "Complex relative clauses with was/wer", vocabTheme: "shopping" },
  { id: 109, name: "Der Konzertsaal", subtitle: "Concerts", level: "B2.2", emoji: "🎼", color: "#8b0000", grammarFocus: "Sentence adverbials", vocabTheme: "hobbies" },
  { id: 110, name: "Das Rechenzentrum", subtitle: "Computing", level: "B2.2", emoji: "🖥️", color: "#00bfff", grammarFocus: "Prepositions (temporal)", vocabTheme: "technology" },
  { id: 111, name: "Die Forschungsbibliothek", subtitle: "Research", level: "B2.2", emoji: "📚", color: "#2f4f4f", grammarFocus: "Connectors (additive)", vocabTheme: "school" },
  { id: 112, name: "Das Eisenbahnmuseum", subtitle: "Railways", level: "B2.2", emoji: "🚂", color: "#4a4a4a", grammarFocus: "Prepositions (local)", vocabTheme: "city" },
  { id: 113, name: "Die Schachmeisterschaft", subtitle: "Chess", level: "B2.2", emoji: "♟️", color: "#1a1a2e", grammarFocus: "Complex syntax (nested clauses)", vocabTheme: "hobbies" },
  { id: 114, name: "Das Planetarium", subtitle: "Science", level: "B2.2", emoji: "🔭", color: "#191970", grammarFocus: "Verbal vs. nominal style", vocabTheme: "nature" },
  { id: 115, name: "Der Filmmusik-Saal", subtitle: "Film Music", level: "B2.2", emoji: "🎵", color: "#4b0082", grammarFocus: "Concessive clauses", vocabTheme: "media" },
  { id: 116, name: "Das Antiquariat", subtitle: "Book Trade", level: "B2.2", emoji: "📜", color: "#8b7355", grammarFocus: "Review: all prepositions and cases", vocabTheme: "shopping" },
  { id: 117, name: "Die Psychiatrie", subtitle: "Mental Health", level: "B2.2", emoji: "🧠", color: "#2f4f4f", grammarFocus: "Connectors (explanatory)", vocabTheme: "body" },
  { id: 118, name: "Die Opernwerkstatt", subtitle: "Opera Production", level: "B2.2", emoji: "🎭", color: "#8b0000", grammarFocus: "Review: all connectors", vocabTheme: "hobbies" },
  { id: 119, name: "Das Observatorium der Zeit", subtitle: "Horology", level: "B2.2", emoji: "⏰", color: "#daa520", grammarFocus: "Review: all tenses", vocabTheme: "time" },
  { id: 120, name: "Das Tor zur Ewigkeit", subtitle: "B2 Exam", level: "B2.2", emoji: "🌟", color: "#ffd700", grammarFocus: "Comprehensive B2 review", vocabTheme: "greetings" },
];

// Grammar pools by level
const grammarPools: Record<string, GrammarRule[]> = {
  A1: [
    { title: "Verb Second", rule: "The conjugated verb always takes the second position in main clauses. The subject can be before or after the verb.", de: "Ich spiele Fußball.", en: "I play football." },
    { title: "W-Questions", rule: "In questions with a question word (W-Wort), the verb is in second position and the question word is first.", de: "Wo wohnst du?", en: "Where do you live?" },
    { title: "Yes/No Questions", rule: "In yes/no questions, the verb is in first position, followed by the subject.", de: "Kommst du morgen?", en: "Are you coming tomorrow?" },
    { title: "Negation with nicht", rule: "'nicht' usually negates the verb or the whole sentence and comes near the end.", de: "Ich esse nicht gern Fisch.", en: "I don't like eating fish." },
    { title: "Noun Genders", rule: "German nouns have three genders: der (masculine), die (feminine), das (neuter). The article must match.", de: "Der Mann, die Frau, das Kind", en: "The man, the woman, the child" },
    { title: "Indefinite Article", rule: "Use ein (masc/neuter) or eine (feminine) for 'a/an'. These have no plural form.", de: "Ein Mann, eine Frau, ein Kind", en: "A man, a woman, a child" },
    { title: "Present Tense Regular", rule: "Regular verbs add endings to the stem: -e, -st, -t, -en, -t, -en.", de: "Ich spiele, du spielst, er spielt", en: "I play, you play, he plays" },
    { title: "Possessive Pronouns", rule: "Possessives agree in gender and case with the noun: mein, dein, sein, ihr, unser, euer, ihr.", de: "Das ist mein Buch.", en: "This is my book." },
  ],
  A2: [
    { title: "Accusative Case", rule: "The accusative is used for direct objects. Masculine der becomes den, ein becomes einen.", de: "Ich sehe den Mann.", en: "I see the man." },
    { title: "Dative Case", rule: "The dative is used for indirect objects. Articles change: der→dem, die→der, das→dem.", de: "Ich helfe der Frau.", en: "I help the woman." },
    { title: "Separable Verbs", rule: "The prefix goes to the end of the clause when conjugated: aufstehen → Ich stehe um 7 Uhr auf.", de: "Ich stehe früh auf.", en: "I get up early." },
    { title: "Modal Verbs", rule: "Modal verbs (können, müssen, wollen, dürfen, sollen, mögen) conjugate irregularly and take an infinitive at the end.", de: "Ich kann gut schwimmen.", en: "I can swim well." },
    { title: "Comparative", rule: "Most adjectives add -er for comparative. Umlauts are added when possible: groß → größer.", de: "Berlin ist größer als Hamburg.", en: "Berlin is bigger than Hamburg." },
    { title: "Superlative", rule: "Most adjectives add -(e)st for superlative. Often used with am: groß → am größten.", de: "Der Mount Everest ist der höchste Berg.", en: "Mount Everest is the highest mountain." },
    { title: "Weil + Verb at End", rule: "In subordinate clauses with weil, the conjugated verb goes to the very end.", de: "Ich bleibe zu Hause, weil ich krank bin.", en: "I stay home because I am sick." },
    { title: "Future with werden", rule: "Use werden + infinitive to express future. The conjugated werden is in position 2.", de: "Ich werde morgen arbeiten.", en: "I will work tomorrow." },
  ],
  B1: [
    { title: "Relative Clauses", rule: "Relative clauses describe nouns. The relative pronoun (der/die/das) matches the noun's gender and case.", de: "Das ist der Mann, der gestern kam.", en: "That is the man who came yesterday." },
    { title: "Passive Voice (Präsens)", rule: "Form passive with werden + past participle. The agent can be mentioned with von/durch.", de: "Das Haus wird gebaut.", en: "The house is being built." },
    { title: "Konjunktiv II (würde)", rule: "Use würde + infinitive for hypothetical situations or polite requests.", de: "Ich würde gern nach Paris reisen.", en: "I would like to travel to Paris." },
    { title: "Infinitive with zu", rule: "Verbs like anfangen, aufhören, versuchen take an infinitive with zu.", de: "Ich höre auf zu rauchen.", en: "I stop smoking." },
    { title: "Two-way Prepositions", rule: "Wechselpräpositionen take accusative for movement, dative for location: in, an, auf, über, unter, vor, hinter, neben, zwischen.", de: "Ich gehe ins Kino. (Akk) / Ich bin im Kino. (Dat)", en: "I go to the cinema. / I am in the cinema." },
    { title: "Plusquamperfekt", rule: "Formed with hatte/war + past participle. Used for actions before another past action.", de: "Er hatte das Buch gelesen, bevor er schlief.", en: "He had read the book before he slept." },
    { title: "Adjective Endings", rule: "Adjective endings depend on the article type (definite, indefinite, none) and case.", de: "Ein guter Mann, die gute Frau, ein gutes Kind", en: "A good man, the good woman, a good child" },
    { title: "Subordinate Clauses", rule: "Conjunctions like dass, obwohl, bevor, nachdem send the verb to the end.", de: "Ich weiß, dass er kommt.", en: "I know that he is coming." },
  ],
  B2: [
    { title: "Konjunktiv II (real forms)", rule: "Some verbs have real Konjunktiv II forms: wäre, hätte, käme, ginge, wüsste.", de: "Wenn ich Zeit hätte, würde ich kommen.", en: "If I had time, I would come." },
    { title: "Nominalization", rule: "Verbs and adjectives can become nouns: das Lesen, die Wichtigkeit, die Schönheit.", de: "Das Lesen ist wichtig für die Bildung.", en: "Reading is important for education." },
    { title: "Participles as Adjectives", rule: "Present and past participles can function as adjectives before nouns.", de: "Der schlafende Hund, das gekochte Ei", en: "The sleeping dog, the boiled egg" },
    { title: "Extended Participial Attributes", rule: "Extended participial phrases can replace relative clauses for a more formal style.", de: "Der in Berlin geborene Künstler...", en: "The artist born in Berlin..." },
    { title: "Modal Particles", rule: "Particles like doch, ja, mal, eben add nuance: doch (insistence), ja (surprise), mal (casual).", de: "Komm doch mal vorbei!", en: "Do come by sometime!" },
    { title: "Double Infinitive", rule: "With modals in perfect tense, both verbs appear as infinitives at the end.", de: "Ich habe ihn nicht kommen hören.", en: "I didn't hear him come." },
    { title: "Gerundive", rule: "zu + infinitive used as an adjective: das zu lösende Problem (the problem to be solved).", de: "Das zu erledigende Arbeit ist wichtig.", en: "The work to be done is important." },
    { title: "Discourse Connectors", rule: "Advanced connectors for formal/academic writing: zudem, darüber hinaus, des Weiteren, folglich.", de: "Zudem ist das Problem komplex.", en: "Furthermore, the problem is complex." },
  ],
};

// Sentence pools
const sentencePools: Record<string, SentenceParts[]> = {
  A1: [
    { parts: ["Ich", "bin", "müde"], translation: "I am tired." },
    { parts: ["Du", "bist", "ein", "guter", "Freund"], translation: "You are a good friend." },
    { parts: ["Er", "hat", "ein", "rotes", "Auto"], translation: "He has a red car." },
    { parts: ["Wir", "gehen", "ins", "Kino"], translation: "We go to the cinema." },
    { parts: ["Die", "Sonne", "scheint", "hell"], translation: "The sun shines brightly." },
    { parts: ["Ich", "esse", "gern", "Pizza"], translation: "I like eating pizza." },
    { parts: ["Das", "Kind", "spielt", "im", "Garten"], translation: "The child plays in the garden." },
    { parts: ["Meine", "Mutter", "kocht", "gut"], translation: "My mother cooks well." },
    { parts: ["Wie", "geht", "es", "dir"], translation: "How are you?" },
    { parts: ["Ich", "komme", "aus", "Deutschland"], translation: "I come from Germany." },
    { parts: ["Der", "Hund", "ist", "groß"], translation: "The dog is big." },
    { parts: ["Sie", "trinkt", "gern", "Kaffee"], translation: "She likes drinking coffee." },
    { parts: ["Das", "Buch", "ist", "interessant"], translation: "The book is interesting." },
    { parts: ["Wir", "haben", "ein", "neues", "Haus"], translation: "We have a new house." },
    { parts: ["Ich", "sehe", "einen", "Film"], translation: "I watch a movie." },
    { parts: ["Er", "fährt", "mit", "dem", "Bus"], translation: "He goes by bus." },
    { parts: ["Die", "Katze", "schläft", "auf", "dem", "Sofa"], translation: "The cat sleeps on the sofa." },
    { parts: ["Ich", "habe", "Hunger"], translation: "I am hungry." },
    { parts: ["Es", "ist", "kalt", "heute"], translation: "It is cold today." },
    { parts: ["Wir", "treffen", "uns", "morgen"], translation: "We meet tomorrow." },
  ],
  A2: [
    { parts: ["Ich", "möchte", "ein", "Ticket", "kaufen"], translation: "I would like to buy a ticket." },
    { parts: ["Er", "steht", "jeden", "Morgen", "früh", "auf"], translation: "He gets up early every morning." },
    { parts: ["Wir", "fahren", "nächste", "Woche", "nach", "Berlin"], translation: "We drive to Berlin next week." },
    { parts: ["Sie", "kann", "sehr", "gut", "schwimmen"], translation: "She can swim very well." },
    { parts: ["Das", "Wetter", "ist", "heute", "schöner", "als", "gestern"], translation: "The weather is nicer today than yesterday." },
    { parts: ["Ich", "bleibe", "zu", "Hause", "weil", "ich", "krank", "bin"], translation: "I stay home because I am sick." },
    { parts: ["Er", "gibt", "mir", "ein", "Geschenk"], translation: "He gives me a present." },
    { parts: ["Wir", "warten", "auf", "den", "Bus"], translation: "We wait for the bus." },
    { parts: ["Ich", "denke", "an", "dich"], translation: "I think of you." },
    { parts: ["Sie", "zieht", "sich", "schnell", "an"], translation: "She dresses quickly." },
    { parts: ["Der", "Film", "war", "sehr", "spannend"], translation: "The movie was very exciting." },
    { parts: ["Ich", "habe", "mein", "Handy", "verloren"], translation: "I lost my cell phone." },
    { parts: ["Wir", "sind", "gestern", "spät", "nach", "Hause", "gekommen"], translation: "We came home late yesterday." },
    { parts: ["Er", "fährt", "mit", "dem", "Zug", "zur", "Arbeit"], translation: "He goes to work by train." },
    { parts: ["Ich", "habe", "keine", "Zeit", "mehr"], translation: "I have no more time." },
    { parts: ["Sie", "liest", "ein", "interessantes", "Buch"], translation: "She reads an interesting book." },
    { parts: ["Das", "Essen", "schmeckt", "sehr", "gut"], translation: "The food tastes very good." },
    { parts: ["Wir", "müssen", "noch", "einkaufen", "gehen"], translation: "We still have to go shopping." },
    { parts: ["Ich", "werde", "dich", "anrufen"], translation: "I will call you." },
    { parts: ["Kannst", "du", "mir", "helfen"], translation: "Can you help me?" },
  ],
  B1: [
    { parts: ["Ich", "habe", "das", "Buch", "gelesen", "das", "du", "mir", "empfohlen", "hast"], translation: "I read the book that you recommended to me." },
    { parts: ["Wenn", "ich", "Zeit", "hätte", "würde", "ich", "gerne", "reisen"], translation: "If I had time, I would like to travel." },
    { parts: ["Das", "Haus", "wird", "nächstes", "Jahr", "gebaut"], translation: "The house will be built next year." },
    { parts: ["Obwohl", "es", "regnet", "gehen", "wir", "spazieren"], translation: "Although it is raining, we go for a walk." },
    { parts: ["Ich", "höre", "auf", "zu", "rauchen"], translation: "I stop smoking." },
    { parts: ["Er", "sagte", "dass", "er", "morgen", "kommen", "würde"], translation: "He said that he would come tomorrow." },
    { parts: ["Das", "ist", "der", "Mann", "mit", "dem", "ich", "gearbeitet", "habe"], translation: "That is the man with whom I worked." },
    { parts: ["Sie", "hat", "das", "Formular", "ausgefüllt"], translation: "She filled out the form." },
    { parts: ["Ich", "freue", "mich", "auf", "den", "Urlaub"], translation: "I look forward to the vacation." },
    { parts: ["Wir", "haben", "uns", "lange", "nicht", "gesehen"], translation: "We haven't seen each other for a long time." },
    { parts: ["Der", "Brief", "wurde", "gestern", "geschrieben"], translation: "The letter was written yesterday." },
    { parts: ["Ich", "zweifle", "daran", "dass", "das", "funktioniert"], translation: "I doubt that this works." },
    { parts: ["Er", "ließ", "sich", "die", "Haare", "schneiden"], translation: "He had his hair cut." },
    { parts: ["Je", "mehr", "ich", "lerne", "desto", "besser", "werde", "ich"], translation: "The more I learn, the better I get." },
    { parts: ["Das", "ist", "das", "interessanteste", "Buch", "das", "ich", "je", "gelesen", "habe"], translation: "That is the most interesting book I have ever read." },
    { parts: ["Bevor", "wir", "gehen", "räumen", "wir", "noch", "auf"], translation: "Before we leave, we clean up first." },
    { parts: ["Ich", "wusste", "nicht", "dass", "er", "so", "viel", "verdient"], translation: "I didn't know that he earns so much." },
    { parts: ["Sie", "könnte", "kommen", "wenn", "sie", "Zeit", "hätte"], translation: "She could come if she had time." },
    { parts: ["Das", "wurde", "von", "meinem", "Bruder", "gemacht"], translation: "That was done by my brother." },
    { parts: ["Nachdem", "ich", "gegessen", "hatte", "ging", "ich", "schlafen"], translation: "After I had eaten, I went to sleep." },
  ],
  B2: [
    { parts: ["Hätte", "ich", "das", "gewusst", "wäre", "ich", "nicht", "gekommen"], translation: "Had I known that, I would not have come." },
    { parts: ["Das", "zu", "lösende", "Problem", "ist", "sehr", "komplex"], translation: "The problem to be solved is very complex." },
    { parts: ["Er", "sagte", "er", "habe", "von", "nichts", "gewusst"], translation: "He said he had known nothing about it." },
    { parts: ["Zudem", "muss", "man", "bedenken", "dass", "die", "Kosten", "steigen"], translation: "Furthermore, one must consider that costs are rising." },
    { parts: ["Wer", "das", "versteht", "kann", "mitmachen"], translation: "Whoever understands that can participate." },
    { parts: ["Alles", "was", "er", "sagte", "war", "falsch"], translation: "Everything he said was wrong." },
    { parts: ["Das", "Haus", "muss", "noch", "gebaut", "werden"], translation: "The house still needs to be built." },
    { parts: ["Ich", "ließ", "mich", "von", "einem", "Experten", "beraten"], translation: "I had myself advised by an expert." },
    { parts: ["An", "deiner", "Stelle", "würde", "ich", "das", "nicht", "tun"], translation: "In your place, I wouldn't do that." },
    { parts: ["Das", "In-Betracht-Ziehen", "aller", "Faktoren", "ist", "wichtig"], translation: "Taking all factors into consideration is important." },
    { parts: ["Er", "verhielt", "sich", "als", "ob", "er", "nichts", "gewusst", "hätte"], translation: "He acted as if he had known nothing." },
    { parts: ["Wenn", "ich", "doch", "bloß", "mehr", "Zeit", "gehabt", "hätte"], translation: "If only I had had more time." },
    { parts: ["Der", "in", "Berlin", "geborene", "Künstler", "stellt", "aus"], translation: "The artist born in Berlin is exhibiting." },
    { parts: ["Es", "wird", "wohl", "morgen", "regnen"], translation: "It will probably rain tomorrow." },
    { parts: ["Komm", "doch", "mal", "vorbei"], translation: "Do come by sometime!" },
    { parts: ["Wessen", "Brot", "ich", "ess", "dessen", "Lied", "ich", "sing"], translation: "Whose bread I eat, his song I sing." },
    { parts: ["Insofern", "stimme", "ich", "zu", "als", "dass", "die", "Kosten", "angemessen", "sind"], translation: "To that extent I agree, in that the costs are reasonable." },
    { parts: ["Das", "Problem", "kann", "gelöst", "werden"], translation: "The problem can be solved." },
    { parts: ["Er", "tut", "so", "als", "wäre", "er", "der", "Chef"], translation: "He acts as if he were the boss." },
    { parts: ["Soweit", "mir", "bekannt", "ist", "ist", "das", "richtig"], translation: "As far as I know, that is correct." },
  ],
};

// Dictation pools
const dictationPools: Record<string, string[]> = {
  A1: [
    "Hallo, ich heiße Anna.",
    "Guten Morgen, wie geht es dir?",
    "Ich komme aus Deutschland.",
    "Das ist mein Bruder.",
    "Die Blume ist rot.",
    "Wir haben ein großes Haus.",
    "Der Hund spielt im Garten.",
    "Ich trinke gern Kaffee.",
    "Es ist heute sehr kalt.",
    "Meine Mutter kocht gut.",
  ],
  A2: [
    "Ich möchte ein Ticket kaufen.",
    "Er steht jeden Morgen früh auf.",
    "Wir fahren nächste Woche nach Berlin.",
    "Das Wetter ist schöner als gestern.",
    "Ich bleibe zu Hause, weil ich krank bin.",
    "Er gibt mir ein schönes Geschenk.",
    "Wir warten auf den Bus.",
    "Sie zieht sich schnell an.",
    "Ich habe mein Handy verloren.",
    "Er fährt mit dem Zug zur Arbeit.",
  ],
  B1: [
    "Ich habe das Buch gelesen, das du mir empfohlen hast.",
    "Wenn ich Zeit hätte, würde ich gerne reisen.",
    "Das Haus wird nächstes Jahr gebaut.",
    "Obwohl es regnet, gehen wir spazieren.",
    "Das ist der Mann, mit dem ich gearbeitet habe.",
    "Der Brief wurde gestern geschrieben.",
    "Ich freue mich auf den Urlaub.",
    "Nachdem ich gegessen hatte, ging ich schlafen.",
    "Er lässt sich die Haare schneiden.",
    "Je mehr ich lerne, desto besser werde ich.",
  ],
  B2: [
    "Hätte ich das gewusst, wäre ich nicht gekommen.",
    "Das zu lösende Problem ist sehr komplex.",
    "Er sagte, er habe von nichts gewusst.",
    "Wer das versteht, kann mitmachen.",
    "Alles, was er sagte, war falsch.",
    "An deiner Stelle würde ich das nicht tun.",
    "Das In-Betracht-Ziehen aller Faktoren ist wichtig.",
    "Es wird wohl morgen regnen.",
    "Der in Berlin geborene Künstler stellt aus.",
    "Wessen Brot ich ess, dessen Lied ich sing.",
  ],
};

// Speaking prompts
const speakingPools: Record<string, string[]> = {
  A1: [
    "Introduce yourself: name, age, where you come from.",
    "Describe your family: who is in it and what are they like?",
    "Talk about your favorite food and why you like it.",
    "Describe your room at home.",
    "What do you do every morning? Describe your routine.",
  ],
  A2: [
    "Describe your last vacation: where did you go and what did you do?",
    "Talk about your best friend: how did you meet and what do you do together?",
    "Describe your favorite hobby and why you enjoy it.",
    "Talk about a typical weekend for you.",
    "Describe your city: what can you do there?",
  ],
  B1: [
    "Discuss your opinion on social media: advantages and disadvantages.",
    "Describe a book or film that influenced you and explain why.",
    "Talk about your career goals and how you plan to achieve them.",
    "Discuss the importance of learning languages in today's world.",
    "Describe a difficult decision you made and how you decided.",
  ],
  B2: [
    "Analyze the impact of technology on modern relationships.",
    "Discuss climate change: what should individuals and governments do?",
    "Describe a complex ethical dilemma and your perspective.",
    "Compare different educational systems and their effectiveness.",
    "Discuss the role of art in society and personal development.",
  ],
};

// Boss question generators
function generateBossQuestions(level: string, theme: string): BossQuestion[] {
  const questions: BossQuestion[] = [];
  const pool = vocabPools[theme] || vocabPools["greetings"];
  
  // 3 vocab questions
  for (let i = 0; i < 3; i++) {
    const word = pool[i % pool.length];
    const wrong = pool[(i + 1) % pool.length];
    questions.push({
      q: `Was bedeutet "${word.de}"?`,
      opts: [word.en, wrong.en, "to wait", "to speak"],
      correct: 0,
      type: "vocab",
      de: word.example,
    });
  }
  
  // 3 grammar questions
  const grammarRules = grammarPools[level] || grammarPools["A1"];
  for (let i = 0; i < 3; i++) {
    const rule = grammarRules[i % grammarRules.length];
    questions.push({
      q: `Welche Regel beschreibt dies?`,
      opts: [rule.title, "Word Order", "Conjugation", "Plural Forms"],
      correct: 0,
      type: "grammar",
      de: rule.de,
    });
  }
  
  // 2 sentence building
  const sentences = sentencePools[level] || sentencePools["A1"];
  for (let i = 0; i < 2; i++) {
    const sent = sentences[i % sentences.length];
    questions.push({
      q: `Setze die Wörter in die richtige Reihenfolge: ${sent.parts.join(", ")}`,
      opts: [sent.translation, "Build the sentence", "Translate to German", "Identify the verb"],
      correct: 0,
      type: "sentence",
      de: sent.parts.join(" "),
    });
  }
  
  // 2 mixed
  questions.push({
    q: "Welcher Satz ist grammatikalisch korrekt?",
    opts: ["Ich habe das Buch gelesen.", "Ich habe gelesen das Buch.", "Ich das Buch habe gelesen.", "Gelesen ich habe das Buch."],
    correct: 0,
    type: "mixed",
  });
  
  questions.push({
    q: "Wähle die richtige Präposition: Ich warte ___ den Bus.",
    opts: ["auf", "für", "mit", "zu"],
    correct: 0,
    type: "mixed",
  });
  
  return questions;
}

// Generate a zone
function generateZone(meta: typeof zoneMeta[0]): Zone {
  const level = meta.level.startsWith("A1") ? "A1" : meta.level.startsWith("A2") ? "A2" : meta.level.startsWith("B1") ? "B1" : "B2";
  const pool = vocabPools[meta.vocabTheme] || vocabPools["greetings"];
  
  // Generate vocab (30-35 words)
  const vocab: VocabWord[] = [];
  for (let i = 0; i < 35; i++) {
    vocab.push(pool[i % pool.length]);
  }
  
  // Generate grammar rules (1-3)
  const grammar = (grammarPools[level] || grammarPools["A1"]).slice(0, 3);
  
  // Generate sentences (20)
  const sentences = (sentencePools[level] || sentencePools["A1"]).slice(0, 20);
  
  // Generate dictation (10)
  const dictation = (dictationPools[level] || dictationPools["A1"]).slice(0, 10);
  
  // Generate speaking (3-5)
  const speaking = (speakingPools[level] || speakingPools["A1"]).slice(0, 5);
  
  // Generate boss questions
  const boss = generateBossQuestions(level, meta.vocabTheme);
  
  return {
    id: meta.id,
    name: meta.name,
    subtitle: meta.subtitle,
    level: meta.level,
    emoji: meta.emoji,
    color: meta.color,
    grammarFocus: meta.grammarFocus,
    vocabTheme: meta.vocabTheme,
    vocab,
    grammar,
    sentences,
    dictation,
    speaking,
    boss,
  };
}

// Generate all 120 zones
export const zones: Zone[] = zoneMeta.map(generateZone);

// Helper to get zone by id
export function getZoneById(id: number): Zone | undefined {
  return zones.find(z => z.id === id);
}

// Helper to get review words from previous zones
export function getReviewWords(zoneId: number, count: number = 30): VocabWord[] {
  const reviewWords: VocabWord[] = [];
  for (let i = zoneId - 1; i >= Math.max(1, zoneId - 5) && reviewWords.length < count; i--) {
    const zone = getZoneById(i);
    if (zone) {
      reviewWords.push(...zone.vocab.slice(0, count - reviewWords.length));
    }
  }
  return reviewWords;
}
