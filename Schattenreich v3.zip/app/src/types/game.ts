export interface VocabWord {
  de: string;
  en: string;
  article?: string | null;
  example: string;
  plural?: string;
}

export interface GrammarRule {
  title: string;
  rule: string;
  de: string;
  en: string;
}

export interface SentenceParts {
  parts: string[];
  translation: string;
}

export interface BossQuestion {
  q: string;
  opts: string[];
  correct: number;
  type: 'vocab' | 'grammar' | 'sentence' | 'mixed';
  de?: string;
}

export interface Zone {
  id: number;
  name: string;
  subtitle: string;
  level: string;
  emoji: string;
  color: string;
  grammarFocus: string;
  vocabTheme: string;
  vocab: VocabWord[];
  grammar: GrammarRule[];
  sentences: SentenceParts[];
  dictation: string[];
  speaking: string[];
  boss: BossQuestion[];
}

export interface GameState {
  screen: 'start' | 'map' | 'zone' | 'trial' | 'recap' | 'boss' | 'vault' | 'shop' | 'settings';
  currentZone: number;
  completedTrials: Record<number, string[]>;
  bossDefeated: Record<number, boolean>;
  xp: number;
  gold: number;
  level: number;
  streak: number;
  recapCompleted: Record<number, boolean>;
  artifacts: string[];
  settings: {
    sound: boolean;
    voice: boolean;
    difficulty: 'normal' | 'hard';
  };
  currentTrial: string | null;
  trialProgress: any;
  vaultUnlocked: boolean;
}

export type TrialType = 
  | 'lexicon'
  | 'sentence'
  | 'listening'
  | 'speaking'
  | 'grammar'
  | 'writing';

export interface TrialState {
  type: TrialType;
  zoneId: number;
  step: number;
  score: number;
  maxScore: number;
  data: any;
}
