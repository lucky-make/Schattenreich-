import { useGameState } from '@/hooks/useGameState';
import type { TrialType } from '@/types/game';
import { StartScreen } from '@/components/StartScreen';
import { WorldMap } from '@/components/WorldMap';
import { ZoneView } from '@/components/ZoneView';
import { HUD } from '@/components/HUD';
import { BertramFox } from '@/components/BertramFox';
import { TrialScreen } from '@/components/TrialScreen';
import { BossBattle } from '@/components/BossBattle';
import { RecapQuiz } from '@/components/RecapQuiz';
import { Vault } from '@/components/Vault';
import { Shop } from '@/components/Shop';
import { Settings } from '@/components/Settings';
import { FloatingParticles } from '@/components/FloatingParticles';
import { AnimatePresence, motion } from 'framer-motion';

function App() {
  const { state, dispatch, isZoneUnlocked, canStartBoss, needsRecap } = useGameState();

  return (
    <div className="min-h-screen bg-deep text-cream relative overflow-hidden">
      <FloatingParticles />
      
      <AnimatePresence mode="wait">
        {state.screen === 'start' && (
          <motion.div key="start" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <StartScreen onStart={() => dispatch({ type: 'START_GAME' })} />
          </motion.div>
        )}
        
        {state.screen !== 'start' && (
          <motion.div
            key="game"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="relative z-10"
          >
            <HUD
              xp={state.xp}
              gold={state.gold}
              level={state.level}
              streak={state.streak}
              currentZone={state.currentZone}
              onMap={() => dispatch({ type: 'GO_TO_MAP' })}
              onVault={() => dispatch({ type: 'GO_TO_VAULT' })}
              onShop={() => dispatch({ type: 'GO_TO_SHOP' })}
              onSettings={() => dispatch({ type: 'GO_TO_SETTINGS' })}
            />
            
            <main className="pt-20 pb-8 px-4 min-h-screen">
              <AnimatePresence mode="wait">
                {state.screen === 'map' && (
                  <motion.div
                    key="map"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                  >
                    <WorldMap
                      zones={Array.from({ length: 120 }, (_, i) => i + 1)}
                      currentZone={state.currentZone}
                      completedZones={Object.keys(state.bossDefeated).map(Number)}
                      unlockedZones={Array.from({ length: 120 }, (_, i) => i + 1).filter(z => isZoneUnlocked(z))}
                      onSelectZone={(id) => dispatch({ type: 'SELECT_ZONE', zoneId: id })}
                    />
                  </motion.div>
                )}
                
                {state.screen === 'zone' && (
                  <motion.div
                    key="zone"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 1.05 }}
                  >
                    <ZoneView
                      zoneId={state.currentZone}
                      completedTrials={state.completedTrials[state.currentZone] || []}
                      bossDefeated={state.bossDefeated[state.currentZone] || false}
                      needsRecap={needsRecap(state.currentZone)}
                      canStartBoss={canStartBoss(state.currentZone)}
                      onStartTrial={(type) => dispatch({ type: 'START_TRIAL', trialType: type })}
                      onStartRecap={() => dispatch({ type: 'START_RECAP' })}
                      onStartBoss={() => dispatch({ type: 'START_BOSS' })}
                      onBack={() => dispatch({ type: 'GO_TO_MAP' })}
                    />
                  </motion.div>
                )}
                
                {state.screen === 'trial' && state.currentTrial && (
                  <motion.div
                    key="trial"
                    initial={{ opacity: 0, x: 100 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -100 }}
                  >
                    <TrialScreen
                      trialType={state.currentTrial as TrialType}
                      zoneId={state.currentZone}
                      onComplete={(score, gold) => dispatch({ type: 'COMPLETE_TRIAL', trialType: state.currentTrial as TrialType, score, goldEarned: gold })}
                      onBack={() => dispatch({ type: 'BACK_TO_ZONE' })}
                    />
                  </motion.div>
                )}
                
                {state.screen === 'boss' && (
                  <motion.div
                    key="boss"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 1.2 }}
                  >
                    <BossBattle
                      zoneId={state.currentZone}
                      onDefeat={(score) => dispatch({ type: 'DEFEAT_BOSS', score })}
                      onFail={() => dispatch({ type: 'FAIL_BOSS' })}
                      onBack={() => dispatch({ type: 'BACK_TO_ZONE' })}
                    />
                  </motion.div>
                )}
                
                {state.screen === 'recap' && (
                  <motion.div
                    key="recap"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <RecapQuiz
                      zoneId={state.currentZone}
                      onComplete={() => dispatch({ type: 'COMPLETE_RECAP' })}
                      onBack={() => dispatch({ type: 'BACK_TO_ZONE' })}
                    />
                  </motion.div>
                )}
                
                {state.screen === 'vault' && (
                  <motion.div
                    key="vault"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <Vault
                      artifacts={state.artifacts}
                      onBack={() => dispatch({ type: 'GO_TO_MAP' })}
                    />
                  </motion.div>
                )}
                
                {state.screen === 'shop' && (
                  <motion.div
                    key="shop"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <Shop
                      gold={state.gold}
                      artifacts={state.artifacts}
                      onBuy={(itemId, cost) => dispatch({ type: 'BUY_ITEM', itemId, cost })}
                      onBack={() => dispatch({ type: 'GO_TO_MAP' })}
                    />
                  </motion.div>
                )}
                
                {state.screen === 'settings' && (
                  <motion.div
                    key="settings"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <Settings
                      settings={state.settings}
                      onUpdate={(s) => dispatch({ type: 'UPDATE_SETTINGS', settings: s })}
                      onReset={() => dispatch({ type: 'RESET' })}
                      onBack={() => dispatch({ type: 'GO_TO_MAP' })}
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </main>
            
            <BertramFox
              message={getBertramMessage(state.screen, state.currentZone, state)}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function getBertramMessage(screen: string, zoneId: number, state: any): string {
  if (screen === 'start') {
    return "Willkommen, Reisende. Ich bin Bertram, dein Führer durch das Schattenreich. Gemeinsam werden wir die deutsche Sprache meistern.";
  }
  if (screen === 'map') {
    const completed = Object.keys(state.bossDefeated).length;
    if (completed === 0) return "Das stille Tor wartet auf dich. Beginne deine Reise mit Zone 1.";
    if (completed < 5) return "Du machst gute Fortschritte! Bleib dran, die nächste Zone wartet.";
    if (completed < 20) return "Beeindruckend! Du beherrschst bereits viele Konzepte.";
    if (completed < 50) return "Du wandelst auf dem Pfad des Meisters. Weiter so!";
    return "Ein wahrer Schattenmeister! Die Ewigkeit ruft.";
  }
  if (screen === 'zone') {
    const progress = (state.completedTrials[zoneId] || []).length;
    if (progress === 0) return `Zone ${zoneId} - ein neues Abenteuer beginnt. Vollende die Prüfungen, um den Boss herauszufordern.`;
    if (progress < 4) return `Noch ${4 - progress} Prüfungen bis zum Boss. Du schaffst das!`;
    if (state.bossDefeated[zoneId]) return "Diese Zone ist gemeistert! Ein würdiger Sieg.";
    return "Der Boss wartet! Stelle dich der Herausforderung.";
  }
  if (screen === 'trial') return "Konzentration ist der Schlüssel. Denke scharf, antwisse klug.";
  if (screen === 'boss') return "Der Moment der Wahrheit! Bleibe ruhig und zeige, was du gelernt hast.";
  if (screen === 'recap') return "Die Vergangenheit prüft dich. Zeige, dass du nichts vergessen hast.";
  if (screen === 'vault') return "Deine Schätze sammeln sich. Jeder Sieg hinterlässt seine Spur.";
  if (screen === 'shop') return "Gold in der Tasche? Vielleicht gibt es hier etwas Nützliches.";
  return "Möge das Licht der Sprache dich führen.";
}

export default App;
