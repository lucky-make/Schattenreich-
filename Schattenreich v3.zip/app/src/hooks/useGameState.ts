import { useReducer, useEffect, useCallback } from 'react';
import type { GameState, TrialType } from '@/types/game';

const SAVE_KEY = 'schattenreich_save_v2';

export const initialState: GameState = {
  screen: 'start',
  currentZone: 1,
  completedTrials: {},
  bossDefeated: {},
  xp: 0,
  gold: 0,
  level: 1,
  streak: 0,
  recapCompleted: {},
  artifacts: [],
  settings: {
    sound: true,
    voice: true,
    difficulty: 'normal',
  },
  currentTrial: null,
  trialProgress: null,
  vaultUnlocked: false,
};

export type GameAction =
  | { type: 'LOAD_SAVE'; payload: GameState }
  | { type: 'RESET' }
  | { type: 'START_GAME' }
  | { type: 'GO_TO_MAP' }
  | { type: 'SELECT_ZONE'; zoneId: number }
  | { type: 'START_TRIAL'; trialType: TrialType }
  | { type: 'COMPLETE_TRIAL'; trialType: TrialType; score: number; goldEarned: number }
  | { type: 'FAIL_TRIAL' }
  | { type: 'START_RECAP' }
  | { type: 'COMPLETE_RECAP' }
  | { type: 'START_BOSS' }
  | { type: 'DEFEAT_BOSS'; score: number }
  | { type: 'FAIL_BOSS' }
  | { type: 'GO_TO_VAULT' }
  | { type: 'GO_TO_SHOP' }
  | { type: 'GO_TO_SETTINGS' }
  | { type: 'UPDATE_SETTINGS'; settings: Partial<GameState['settings']> }
  | { type: 'BUY_ITEM'; itemId: string; cost: number }
  | { type: 'ADD_ARTIFACT'; artifact: string }
  | { type: 'UPDATE_STREAK'; streak: number }
  | { type: 'BACK_TO_ZONE' };

function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case 'LOAD_SAVE':
      return { ...initialState, ...action.payload, screen: 'map' };
    case 'RESET':
      return initialState;
    case 'START_GAME':
      return { ...state, screen: 'map' };
    case 'GO_TO_MAP':
      return { ...state, screen: 'map', currentTrial: null, trialProgress: null };
    case 'SELECT_ZONE': {
      const zoneId = action.zoneId;
      const previousZone = zoneId - 1;
      if (previousZone > 0 && !state.bossDefeated[previousZone]) {
        return state;
      }
      return { ...state, currentZone: zoneId, screen: 'zone' };
    }
    case 'START_TRIAL':
      return { ...state, screen: 'trial', currentTrial: action.trialType };
    case 'COMPLETE_TRIAL': {
      const zoneTrials = state.completedTrials[state.currentZone] || [];
      if (zoneTrials.includes(action.trialType)) {
        return { ...state, screen: 'zone' };
      }
      const newTrials = {
        ...state.completedTrials,
        [state.currentZone]: [...zoneTrials, action.trialType],
      };
      const newXp = state.xp + action.score;
      const newGold = state.gold + action.goldEarned;
      const newLevel = Math.floor(newXp / 500) + 1;
      return {
        ...state,
        completedTrials: newTrials,
        xp: newXp,
        gold: newGold,
        level: newLevel,
        screen: 'zone',
        currentTrial: null,
      };
    }
    case 'FAIL_TRIAL':
      return { ...state, screen: 'zone', currentTrial: null };
    case 'START_RECAP':
      return { ...state, screen: 'recap' };
    case 'COMPLETE_RECAP': {
      return {
        ...state,
        recapCompleted: { ...state.recapCompleted, [state.currentZone]: true },
        screen: 'zone',
      };
    }
    case 'START_BOSS':
      return { ...state, screen: 'boss' };
    case 'DEFEAT_BOSS': {
      const newXp = state.xp + 200;
      const newGold = state.gold + 150;
      const newLevel = Math.floor(newXp / 500) + 1;
      const newArtifacts = [...state.artifacts];
      if (!newArtifacts.includes(`zone-${state.currentZone}`)) {
        newArtifacts.push(`zone-${state.currentZone}`);
      }
      return {
        ...state,
        bossDefeated: { ...state.bossDefeated, [state.currentZone]: true },
        xp: newXp,
        gold: newGold,
        level: newLevel,
        artifacts: newArtifacts,
        vaultUnlocked: newArtifacts.length >= 3,
        screen: 'zone',
      };
    }
    case 'FAIL_BOSS': {
      const penalty = Math.max(0, state.gold - 40);
      return { ...state, gold: penalty, screen: 'zone' };
    }
    case 'GO_TO_VAULT':
      return { ...state, screen: 'vault' };
    case 'GO_TO_SHOP':
      return { ...state, screen: 'shop' };
    case 'GO_TO_SETTINGS':
      return { ...state, screen: 'settings' };
    case 'UPDATE_SETTINGS':
      return { ...state, settings: { ...state.settings, ...action.settings } };
    case 'BUY_ITEM': {
      if (state.gold < action.cost) return state;
      return {
        ...state,
        gold: state.gold - action.cost,
        artifacts: [...state.artifacts, action.itemId],
      };
    }
    case 'ADD_ARTIFACT':
      return {
        ...state,
        artifacts: [...state.artifacts, action.artifact],
      };
    case 'UPDATE_STREAK':
      return { ...state, streak: action.streak };
    case 'BACK_TO_ZONE':
      return { ...state, screen: 'zone' };
    default:
      return state;
  }
}

export function useGameState() {
  const [state, dispatch] = useReducer(gameReducer, initialState);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(SAVE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        dispatch({ type: 'LOAD_SAVE', payload: parsed });
      }
    } catch (e) {
      console.warn('Failed to load save:', e);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('Failed to save:', e);
    }
  }, [state]);

  const isZoneUnlocked = useCallback((zoneId: number) => {
    if (zoneId === 1) return true;
    if (zoneId <= 0) return false;
    return state.bossDefeated[zoneId - 1] === true;
  }, [state.bossDefeated]);

  const isZoneCompleted = useCallback((zoneId: number) => {
    return state.bossDefeated[zoneId] === true;
  }, [state.bossDefeated]);

  const getZoneProgress = useCallback((zoneId: number) => {
    const trials = state.completedTrials[zoneId] || [];
    return trials.length;
  }, [state.completedTrials]);

  const canStartBoss = useCallback((zoneId: number) => {
    const trials = state.completedTrials[zoneId] || [];
    return trials.length >= 4;
  }, [state.completedTrials]);

  const needsRecap = useCallback((zoneId: number) => {
    if (zoneId === 1) return false;
    if (!isZoneUnlocked(zoneId)) return false;
    return !state.recapCompleted[zoneId];
  }, [state.recapCompleted, isZoneUnlocked]);

  return {
    state,
    dispatch,
    isZoneUnlocked,
    isZoneCompleted,
    getZoneProgress,
    canStartBoss,
    needsRecap,
  };
}
