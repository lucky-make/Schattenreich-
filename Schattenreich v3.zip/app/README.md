# Schattenreich: The Shadow Language

Ein episches, verträumtes Deutsch-Lernabenteuer. 120 Zonen, 6 Prüfungstypen, 4000+ Wörter — von A1 bis B2.

## Spiel starten

**Live-Demo:** [https://6xmigly2qy22q.kimi.show](https://6xmigly2qy22q.kimi.show)

## Auf GitHub Pages hosten

### Option 1: Mit dem fertigen `dist/` Ordner

1. Lade den `dist/` Ordner aus diesem Repo herunter
2. Erstelle ein neues GitHub Repository
3. Lade den gesamten `dist/` Inhalt hoch (entweder direkt auf `main` oder auf einen `gh-pages` Branch)
4. Gehe in deinem Repo zu **Settings → Pages**
5. Wähle als Source "Deploy from a branch" und wähle `main` (oder `gh-pages`)
6. Dein Spiel ist live unter `https://DEIN-USERNAME.github.io/DEIN-REPO-NAME/`

### Option 2: Quellcode selbst bauen

```bash
git clone https://github.com/DEIN-USERNAME/DEIN-REPO.git
cd schattenreich
npm install
npm run build
```

Der `dist/` Ordner enthält dann alle Dateien, die du hosten musst.

## Projektstruktur

```
src/
├── App.tsx              # Haupt-Game-Engine
├── index.css            # Dark Fantasy Theme
├── types/game.ts        # TypeScript Definitionen
├── data/
│   ├── vocabPools.ts    # 4000+ deutsche Vokabeln
│   └── zones.ts         # Alle 120 Zonen mit Inhalt
├── hooks/
│   └── useGameState.ts  # useReducer + localStorage Save
└── components/
    ├── StartScreen.tsx   # Titelbildschirm
    ├── WorldMap.tsx      # 120-Zonen Weltkarte
    ├── ZoneView.tsx      # Zone mit 6 Prüfungen
    ├── TrialScreen.tsx   # Lexicon/Satz/Hör/Sprech/Grammatik/Schreib
    ├── BossBattle.tsx    # Adaptive Bosskämpfe
    ├── RecapQuiz.tsx     # Täglicher Rückblick
    ├── BertramFox.tsx    # Der Fuchs-Begleiter
    ├── HUD.tsx           # XP/Gold/Streak-Anzeige
    ├── Vault.tsx         # Artefakt-Sammlung
    ├── Shop.tsx          # Gildenladen
    ├── Settings.tsx      # Einstellungen
    └── FloatingParticles.tsx # Partikel-Animation
```

## Features

| Feature | Beschreibung |
|---------|-------------|
| 120 Zonen | Vollständiger A1-B2 Lehrplan |
| 6 Prüfungstypen | Lexicon, Satz, Hör, Sprech, Grammatik, Schreiben |
| Bosskämpfe | 10 adaptive Fragen pro Zone |
| Rückblicke | Tägliche Wiederholung vorheriger Zonen |
| Bertram der Fuchs | Persönlicher Sprachführer |
| Speicherung | localStorage für Fortschritt |
| TTS | Web Speech API für Aussprache |
| Erfolge | XP, Gold, Streak, Artefakte |

## Technologie

- React 19 + TypeScript
- Vite
- Tailwind CSS
- Framer Motion (Animationen)
- shadcn/ui
- Canvas Confetti

## Lizenz

MIT — Nutze, modifiziere und teile das Spiel frei.
